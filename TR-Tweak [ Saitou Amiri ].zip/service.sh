#!/system/bin/sh
MODDIR=${0%/*}
chmod 0777 /data/adb/modules/TRT/ram
exec /data/adb/modules/TRT/ram
$MODDIR/trt.sh > /dev/null
