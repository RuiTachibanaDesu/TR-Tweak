SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"
modver=$(grep_prop version $TMPDIR/module.prop)
modname=$(grep_prop name $TMPDIR/module.prop)
modauthor=$(grep_prop author $TMPDIR/module.prop)
moddir="/data/adb/modules"

REPLACE = "/system/product/overlay"

# Check for existence of /system/xbin directory.
if [[ ! -d "/sbin/.magisk/mirror/system/xbin" ]]; then
  # Use /system/bin instead of /system/xbin.
  mkdir -p "$MODPATH/system/bin"
  mv "$MODPATH/system/xbin/sqlite3" "$MODPATH/system/bin"
  rmdir "$MODPATH/system/xbin"
  ui_print "SQLite installed successfully..."
  ui_print ""
else
  ui_print "SQLite not installed  "
  ui_print ""
fi

[[ "$(getprop ro.miui.ui.version.name)" ]] && miui=true

if [[ "$miui" == "true" ]]; then
  ui_print "osp graphics composter not installed"
else
  unzip -o "$ZIPFILE" 'system/vendor/etc/init/*' -d $MODPATH >&2
  ui_print "Aosp graphics composter installed successfully..."
fi


#Patch the XML and place the modified one to the original directory
ui_print "- Patching XML files"
location=$(xml=$(find /system/ /system_ext/ /product/ /vendor/ -iname "*.xml");for i in $xml; do if grep -q 'allow-unthrottled-location package="com.google.android.gms"' $ROOT$i 2>/dev/null; then echo "$i";fi; done)
ignore=$(xml=$(find /system/ /system_ext/ /product/ /vendor/ -iname "*.xml");for i in $xml; do if grep -q 'allow-ignore-location-settings package="com.google.android.gms"' $ROOT$i 2>/dev/null; then echo "$i";fi; done)

for i in $location $ignore
do
mkdir -p `dirname $MODPATH$i`
cp -af $ROOT$i $MODPATH$i
sed -i '/allow-unthrottled-location package="com.google.android.gms"/d;/allow-ignore-location-settings package="com.google.android.gms"/d' $MODPATH$i
done

for i in product vendor
do
if [ -d $MODPATH/$i ]; then
if [ ! -d $MODPATH/system/$i ]; then
sleep 1
ui_print "- Moving files to /system partition"
mkdir -p $MODPATH/system/$i
mv -f $MODPATH/$i $MODPATH/system/
else
rm -rf $MODPATH/$i
fi
fi
done

# Search and patch any conflicting modules (if present)
# Search conflicting XML files
conflict1=$(xml=$(find /data/adb -iname "*.xml");for i in $xml; do if grep -q 'allow-unthrottled-location package="com.google.android.gms"' $i 2>/dev/null; then echo "$i";fi; done)
conflict2=$(xml=$(find /data/adb -iname "*.xml");for i in $xml; do if grep -q 'allow-ignore-location-settings package="com.google.android.gms"' $i 2>/dev/null; then echo "$i";fi; done)
for i in $conflict1 $conflict2
do
search=$(echo "$i" | sed -e 's/\// /g' | awk '{print $4}')
ui_print "- Conflicting modules detected"
ui_print "   $search"
sed -i '/allow-unthrottled-location package="com.google.android.gms"/d;/allow-ignore-location-settings package="com.google.android.gms"/d' $i
done

# Dex2oat Optimizer
[[ "$IS64BIT" == "true" ]] && mv -f "$MODPATH/system/bin/dex2oat_opt64" "$MODPATH/system/bin/dex2oat_opt" && rm -f $MODPATH/system/bin/dex2oat_opt32 || mv -f "$MODPATH/system/bin/dex2oat_opt32" "$MODPATH/system/bin/dex2oat_opt" && rm -f $MODPATH/system/bin/dex2oat_opt64

sleep 1

print_modname() {
  ui_print " "
  ui_print " "
ui_print "----------------------------------------------------------------"
ui_print " Name $modname"
ui_print " Current version $modver"
ui_print " Author $modauthor"
ui_print "----------------------------------------------------------------"
sleep 1
ui_print " Powered By : Vendora "
sleep 1
ui_print " Device : $(getprop ro.product.marketname)"
sleep 1
ui_print " Codename : $(getprop ro.build.product)"
sleep 1
ui_print " Brand : $(getprop ro.product.system.manufacturer)"
sleep 1
ui_print " Processor : $(getprop ro.soc.model)"
sleep 1
ui_print " CPU : $(getprop ro.soc.manufacturer)"
sleep 1
ui_print " Android : $(getprop ro.build.version.release)"
sleep 1
ui_print "Kernel : $(uname -r)"
sleep 1
ui_print " RAM : $(free | grep Mem |  awk '{print $2}')"
sleep 1
ui_print " Removed Cache, Please Wait..."
rm -rf /cache/dalvik-cache
rm -rf /data/cache
rm -rf /data/dalvik-cache
sleep 3
ui_print " Running FStrim, Please Wait... "
fstrim -v /data
fstrim -v /system
fstrim -v /cache

  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print " KS A B A R  L A G I  D I  E X T R A K  A N J I N K"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'script/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'sepolicy.rule' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'addon/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" module.prop -d $MODPATH >&2
  unzip -o "$ZIPFILE" post-fs-data.sh -d $MODPATH >&2
  unzip -o "$ZIPFILE" service.sh -d $MODPATH >&2
  mkdir -p $MODPATH/system/bin
  unzip -o "$ZIPFILE" 'TRT' -d $MODPATH/system/bin >&2
  chmod +x $MODPATH/system/bin/TRT
  
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  ui_print "- Setting permissions"
  set_perm_recursive $SCRIPT_PATH root root 0777 0755
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
  set_perm $MODPATH/system/bin/P0 0 0 0755 0755
  set_perm $MODPATH/system/bin/P1 0 0 0755 0755
  

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

# You can add more functions to assist your custom script code

enforce_install_from_app() {
  if $BOOTMODE; then
    ui_print "- Installing from Magisk / KernelSU app"
  else
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery sucks"
    ui_print "! Please install from Magisk / KernelSU app"
    abort "*********************************************************"
  fi
}

check_magisk_version() {
  ui_print "- Magisk version: $MAGISK_VER_CODE"
  if [ "$MAGISK_VER_CODE" -lt 25000 ]; then
    ui_print "*********************************************************"
    ui_print "! Please install Magisk v25.0+ (25000+)"
    abort    "*********************************************************"
  fi
}

check_ksu_version() {
  ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
  if ! [ "$KSU_KERNEL_VER_CODE" ] || [ "$KSU_KERNEL_VER_CODE" -lt 10940 ]; then
    ui_print "*********************************************************"
    ui_print "! KernelSU version is too old!"
    ui_print "! Please update KernelSU to latest version"
    abort    "*********************************************************"
  elif [ "$KSU_KERNEL_VER_CODE" -ge 20000 ]; then
    ui_print "*********************************************************"
    ui_print "! KernelSU version abnormal!"
    ui_print "! Please integrate KernelSU into your kernel"
    ui_print "  as submodule instead of copying the source code"
    abort    "*********************************************************"
  fi
  if ! [ "$KSU_VER_CODE" ] || [ "$KSU_VER_CODE" -lt 10942 ]; then
    ui_print "*********************************************************"
    ui_print "! ksud version is too old!"
    ui_print "! Please update KernelSU Manager to latest version"
    abort    "*********************************************************"
  fi
}

check_zygisksu_version() {
  ZYGISKSU_VERSION=$(cat /data/adb/modules/zygisksu/module.prop | grep versionCode | sed 's/versionCode=//g')
  ui_print "- Zygisksu version: $ZYGISKSU_VERSION"
  if ! [ "$ZYGISKSU_VERSION" ] || [ "$ZYGISKSU_VERSION" -lt 45 ]; then
    ui_print "*********************************************************"
    ui_print "! Zygisksu version is too old!"
    ui_print "! Please update Zygisksu to latest version"
    abort    "*********************************************************"
  fi
}

CHECK1() {
D=$(getprop ro.product.device 2>/dev/null)
P=$(getprop ro.build.product 2>/dev/null)
VD=$(getprop ro.product.vendor.device 2>/dev/null)
VP=$(getprop ro.vendor.product.device 2>/dev/null)
DN=whyred

case "$DN" in
 "$D"|"$P"|"$VD"|"$VP")
  why=1
 ;;
 *)
  why=0
 ;;
esac

sleep $TIME

if [ "$why" == "0" ]; then
 ui_print "* Snapdragon only.!!!"
 abort "* Err Code1 : Installation Not Approved , Aborting !!! *"
elif [ "$why" == "1" ]; then
 ui_print "* Installation Approved Level 1 , Snapdragon detected *"
fi;
}

CHECK2() {
if [ -e $SBIN/disable_thermal-throttle/disable ]; then
 Conf=1
elif [ -d $SBIN/disable_thermal-throttle ]; then
 Conf=1
elif [ -e $SBIN/FThermalXWH/disable ]; then
 Conf=1
elif [ -d $SBIN/FThermalXWH ]; then
 Conf=1
elif [ -e $SBIN/InfernoThermalsForWhyredv1/disable ]; then
 Conf=1
elif [ -d $SBIN/InfernoThermalsForWhyredv1 ]; then
 Conf=1
elif [ -e $SBIN/InfernoThermalsForWhyredv2/disable ]; then
 Conf=1
elif [ -d $SBIN/InfernoThermalsForWhyredv2 ]; then
 Conf=1
elif [ -e $SBIN/neothermalwhyred/disable ]; then
 Conf=1
elif [ -d $SBIN/neothermalwhyred ]; then
 Conf=1
elif [ -e $SBIN/uni-thermal-mod-whyred/disable ]; then
 Conf=1
elif [ -d $SBIN/uni-thermal-mod-whyred ]; then
 Conf=1
else
 Conf=0
fi;

sleep $TIME

if [ "Conf" == "1" ]; then
 ui_print "* No Thermal Detected..!!!"
 sleep 1
 abort "* Err Code : Installation Not Approved  , Aborting !!! *"
 sleep 1
elif [ "$Conf" == "0" ]; then
sleep 1
 ui_print "* Installation Approved Level  , Thermal Detected *"
 ui_print "$(getprop | grep thermal) "
 sleep 1
fi;
}


run_addon() {
    # Ganti dengan path ke skrip yang ingin dijalankan setelah reboot

    # Pastikan skrip memiliki izin eksekusi
    sleep 1
    ui_print "Mengatur Izin "
    chmod -R 0755 /data/local/tmp/
    chmod +x /data/local/tmp/addon/addon.sh
    sleep 1
    ui_print "Install addon"
    chmod +x "$ZIPFILE/addon/addon.sh*"
    unzip -o "$ZIPFILE" 'addon/addon.sh*' -d /data/local/tmp/
    sleep 2
    # Pindahkan skrip ke direktori post-fs-data.d
    chmod -R 0755 /data/local/tmp/
    chmod +x /data/local/tmp/addon/addon.sh
    ui_print "Skrip akan dijalankan setelah reboot."
    exit

}

hapus_addon() {
    cd /data/local/tmp/
    rm -rf /data/local/tmp/addon.sh
    sleep 1
    ui_print "add on sudah terhapus perubahan terjadi setelah reboot"
    exit
}


# Fungsi untuk menginstal modul
install_module() {
    on_install
    enforce_install_from_app
    if [ "$KSU" ]; then
        check_ksu_version
        check_zygisksu_version
    else
        check_magisk_version
    fi
    sleep 1
    CHECK2
    sleep 1
    # Check architecture
    if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x86" ] && [ "$ARCH" != "x64" ]; then
        abort "! Unsupported platform: $ARCH"
    else
        ui_print "- Device platform: $ARCH"
    fi
    print_modname
    
}

# Fungsi untuk menghapus modul
remove_module() {
    cd /data/
    rm -rf /data/adb/modules/TRT
    sleep 2
    rm -rf /data/local/tmp/addon.sh

    ui_print "- module telah di un install "
    ui_print "- Penerapan akan dimulai setelah reboot."
    sleep 1
    exit
}


chmod -R 0755 $MODPATH/addon/Volume-Key-Selector/tools

chooseport_legacy() {
    # Keycheck binary by someone755 @Github, idea for code below by Zappo @xda-developers
    # Calling it first time detects previous input. Calling it second time will do what we want
    [ "$1" ] && local delay=$1 || local delay=60
    local error=false
    while true; do
        timeout 0 $MODPATH/addon/Volume-Key-Selector/tools/$ARCH32/keycheck
        timeout $delay $MODPATH/addon/Volume-Key-Selector/tools/$ARCH32/keycheck
        local sel=$?
        if [ $sel -eq 42 ]; then
            return 0
        elif [ $sel -eq 41 ]; then
            return 1
        elif $error; then
            abort "Error!"
        else
            error=true
            echo "Try again!"
        fi
    done
}

chooseport() {
    # Original idea by chainfire and ianmacd @xda-developers
    [ "$1" ] && local delay=$1 || local delay=60
    local error=false 
    while true; do
        local count=0
        while true; do
            timeout $delay /system/bin/getevent -lqc 1 2>&1 > $TMPDIR/events &
            sleep 0.5; count=$((count + 1))
            if (`grep -q 'KEY_VOLUMEUP *DOWN' $TMPDIR/events`); then
                return 0
            elif (`grep -q 'KEY_VOLUMEDOWN *DOWN' $TMPDIR/events`); then
                return 1
            fi
            [ $count -gt 60 ] && break
        done
        if $error; then
            echo "Trying keycheck method..."
            export chooseport=chooseport_legacy VKSEL=chooseport_legacy
            chooseport_legacy $delay
            return $?
        else
            error=true
            echo "Volume key not detected, try again!"
        fi
    done
}

InstallGki() {

VKSEL=chooseport


# Skrip instalasi modul Magisk
ui_print "TR-Tweak" # Perubahan pada pesan selamat datang
ui_print "Volume up (+) to change selection"
ui_print "Volume down (-) to decide"
sleep 1

A=1 # Menu utama
while true; do
    case $A in
        1 ) TEXT="Install module";;
        2 ) TEXT="Remove module";;
    esac
    ui_print "$A - $TEXT"
    if $VKSEL; then
        A=$((A + 1))
    else
        break
    fi
    if [ $A -gt 2 ]; then
        A=1
    fi
done

ui_print ""
ui_print "You have selected: $A - $TEXT"

case $A in
    1 ) install_module;;
    2 ) remove_module;;
esac
}


GpuCh() {
        # Skrip instalasi modul Magisk
ui_print "Changer renderer" # Perubahan pada pesan selamat datang
ui_print " 1) SkiaGL "
ui_print " 2) SkiaVK"
ui_print " 3) OpenGL"
ui_print " 4) Vulkan"
ui_print " 5) Skip"
ui_print "Volume up (+) to change selection"
ui_print "Volume down (-) to decide"
sleep 1

VKSEL=chooseport

B=1 # Menu utama
while true; do
    case $B in
        1 ) TEXT="SkiaGL";;
        2 ) TEXT="SkiaVK";;
        3 ) TEXT="OpenGL";;
        4 ) TEXT="Vulkan";;
        5 ) TEXT="Skip";;
    esac
    ui_print "$B - $TEXT"
    if $VKSEL; then
        B=$((B + 1))
    else
        break
    fi
    if [ $B -gt 5 ]; then
        B=1
    fi
done

ui_print ""
ui_print "Render Gpu : $B - $TEXT"

case $B in
    1 ) SkiaGL;;
    2 ) SkiaVK;;
    3 ) OpenGL;;
    4 ) Vulkan;;
    5 ) Skip;;
esac 
}

Skip() {
    ui_print "-Install stock gpu "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/Skip/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-gpu render tidak diubah"
}

SkiaGL() {
VKSEL=chooseport

# Skrip untuk menu opsi GPU
ui_print "GPU Options Menu" # Pesan selamat datang untuk menu baru
ui_print "Press Volume up (+) to switch options"
ui_print "Press Volume down (-) to select"
sleep 1

C=1 # Menu utama
while true; do
    case $C in
        1 ) TEXT="Core 2 Duo (C2D) ( CPU 25% - GPU 75% )";;
        2 ) TEXT="Multi Depth (MDP) ( 100% CPU Core )";;
        3 ) TEXT="Dynamic (DYN) CPU And GPU ( CPU 50% - GPU 50% )";;
        4 ) TEXT="GPU (GPU) GPU Only";;
        5 ) TEXT="Skip ( Don't Change GPU Composition )";;
    esac
    ui_print "$C - $TEXT"
    if $VKSEL; then
        C=$((C + 1))
    else
        break
    fi
    if [ $C -gt 5 ]; then
        C=1
    fi
done

ui_print ""
ui_print "You have selected: $C - $TEXT"

case $C in
    1) apply_DYN_GPU_setting_SkiaGL;;
    2) apply_MDP_GPU_setting_SkiaGL;;
    3) apply_C2D_GPU_setting_SkiaGL;;
    4) apply_GPU_GPU_setting_SkiaGL;;
    5) Skip;;
esac

}

SkiaVK() {
VKSEL=chooseport

# Skrip untuk menu opsi GPU
ui_print "GPU Options Menu" # Pesan selamat datang untuk menu baru
ui_print "Press Volume up (+) to switch options"
ui_print "Press Volume down (-) to select"
sleep 1

C=1 # Menu utama
while true; do
    case $C in
        1 ) TEXT="Core 2 Duo (C2D) ( CPU 25% - GPU 75% )";;
        2 ) TEXT="Multi Depth (MDP) ( 100% CPU Core )";;
        3 ) TEXT="Dynamic (DYN) CPU And GPU ( CPU 50% - GPU 50% )";;
        4 ) TEXT="GPU (GPU) GPU Only";;
        5 ) TEXT="Skip ( Don't Change GPU Composition )";;
    esac
    ui_print "$C - $TEXT"
    if $VKSEL; then
        C=$((C + 1))
    else
        break
    fi
    if [ $C -gt 5 ]; then
        C=1
    fi
done

ui_print ""
ui_print "You have selected: $C - $TEXT"

case $C in
    1) apply_DYN_GPU_setting_SkiaVK;;
    2) apply_MDP_GPU_setting_SkiaVK;;
    3) apply_C2D_GPU_setting_SkiaVK;;
    4) apply_GPU_GPU_setting_SkiaVK;;
    5) Skip;;
esac

}

OpenGL() {
VKSEL=chooseport

# Skrip untuk menu opsi GPU
ui_print "GPU Options Menu" # Pesan selamat datang untuk menu baru
ui_print "Press Volume up (+) to switch options"
ui_print "Press Volume down (-) to select"
sleep 1

C=1 # Menu utama
while true; do
    case $C in
        1 ) TEXT="Core 2 Duo (C2D) ( CPU 25% - GPU 75% )";;
        2 ) TEXT="Multi Depth (MDP) ( 100% CPU Core )";;
        3 ) TEXT="Dynamic (DYN) CPU And GPU ( CPU 50% - GPU 50% )";;
        4 ) TEXT="GPU (GPU) GPU Only";;
        5 ) TEXT="Skip ( Don't Change GPU Composition )";;
    esac
    ui_print "$C - $TEXT"
    if $VKSEL; then
        C=$((C + 1))
    else
        break
    fi
    if [ $C -gt 5 ]; then
        C=1
    fi
done

ui_print ""
ui_print "You have selected: $C - $TEXT"

case $C in
    1) apply_DYN_GPU_setting_OpenGl;;
    2) apply_MDP_GPU_setting_OpenGl;;
    3) apply_C2D_GPU_setting_OpenGl;;
    4) apply_GPU_GPU_setting_OpenGl;;
    5) Skip;;
esac

}

Vulkan() {
VKSEL=chooseport

# Skrip untuk menu opsi GPU
ui_print "GPU Options Menu" # Pesan selamat datang untuk menu baru
ui_print "Press Volume up (+) to switch options"
ui_print "Press Volume down (-) to select"
sleep 1

C=1 # Menu utama
while true; do
    case $C in
        1 ) TEXT="Core 2 Duo (C2D) ( CPU 25% - GPU 75% )";;
        2 ) TEXT="Multi Depth (MDP) ( 100% CPU Core )";;
        3 ) TEXT="Dynamic (DYN) CPU And GPU ( CPU 50% - GPU 50% )";;
        4 ) TEXT="GPU (GPU) GPU Only";;
        5 ) TEXT="Skip ( Don't Change GPU Composition )";;
    esac
    ui_print "$C - $TEXT"
    if $VKSEL; then
        C=$((C + 1))
    else
        break
    fi
    if [ $C -gt 5 ]; then
        C=1
    fi
done

ui_print ""
ui_print "You have selected: $C - $TEXT"

case $C in
    1) apply_DYN_GPU_setting_Vulkan;;
    2) apply_MDP_GPU_setting_Vulkan;;
    3) apply_C2D_GPU_setting_Vulkan;;
    4) apply_GPU_GPU_setting_Vulkan;;
    5) Skip;;
esac

ui_print "  Zram size..."
ui_print "  1. 2gb"
ui_print "  2. 3gb"
ui_print "  3. 4gb"
ui_print "  4. 5gb"
ui_print "  5. 6gb"
ui_print "  6. Skip"
ui_print ""
sleep 1
D=1
while true; do
    ui_print "  $D"
    if $VKSEL; then
        CD=$((D + 1))
    else
        break
    fi
    if [ $D -gt 3 ]; then
        D=1
    fi
done
ui_print "  Selected: $D"
case $C in
    1 ) TEXT3="2gb"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=2048M/' $MODPATH/service.sh;;
    2 ) TEXT3="3gb"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=3072M/' $MODPATH/service.sh;;
    3 ) TEXT3="4gb"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=4096M/' $MODPATH/service.sh;;
    4 ) TEXT3="5gb"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=5120M/' $MODPATH/service.sh;;
    5 ) TEXT3="6gb"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=6144M/' $MODPATH/service.sh;;
    6 ) TEXT3="Skip"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=0M/' $MODPATH/service.sh;;
esac
sleep 0.7
ui_print "  • $TEXT3"
ui_print ""
sleep 1.5
}

apply_DYN_GPU_setting_SkiaGL() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/DYN/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_MDP_GPU_setting_SkiaGL() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/MDP/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_C2D_GPU_setting_SkiaGL() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/C2D/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_GPU_GPU_setting_SkiaGL() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/GPU/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}
    
apply_DYN_GPU_setting_SkiaVK() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/DYN/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_MDP_GPU_setting_SkiaVK() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/MDP/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_C2D_GPU_setting_SkiaVK() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/C2D/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_GPU_GPU_setting_SkiaVK() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/GPU/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}
    
apply_DYN_GPU_setting_OpenGL() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/DYN/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_MDP_GPU_setting_OpenGL() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/MDP/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_C2D_GPU_setting_OpenGL() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/C2D/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_GPU_GPU_setting_OpenGL() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/GPU/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}
    
apply_DYN_GPU_setting_Vulkan() {    
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/DYN/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_MDP_GPU_setting_Vulkan() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/MDP/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_C2D_GPU_setting_Vulkan() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/C2D/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}

apply_GPU_GPU_setting_Vulkan() {
    ui_print "-GPU Render Composition "
    sleep 2
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/GPU/*' -d $TMPDIR >&2
    sleep 1
    ui_print "-GPU Render Has Been Changed "
}
