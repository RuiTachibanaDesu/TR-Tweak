#!/system/bin/sh

sleep 30
# Log create
log-trt() {
    local message="$1"
    echo "[$(date "+%H:%M:%S")] $message" >> /data/adb/modules/TRT/trt.log
}

# Function to log error messages
log-error() {
    local message="$1"
    echo "[$(date "+%H:%M:S")] $message" >> /data/adb/modules/TRT/trt-logging-error.log
}

write() {
    local file="$1"
    local value="$2"

    # Check if the file exists
    if [ ! -f "$file" ]; then
        log-error "Error: File $file does not exist."
        return 1
    fi

    # Make file writable
    chmod +w "$file" 2>/dev/null

    # Write new value, bail out if it fails
    if ! echo "$value" >"$file" 2>/dev/null; then
        log-error "Error: Failed to write to $file."
        return 1
    else
        return 0
    fi
}

# Modify the paths for logs
LOG=/data/adb/modules/TRT/trt.log
ERROR_LOG=/data/adb/modules/TRT/trt-logging-error.log

if [ -f "$LOG" ]; then
    rm "$LOG"
fi

if [ -f "$ERROR_LOG" ]; then
    rm "$ERROR_LOG"
fi

touch "$LOG"
if [ $? -ne 0 ]; then
    log-error "Error: Unable to create log file $LOG"
    exit 1
fi

touch "$ERROR_LOG"
if [ $? -ne 0 ]; then
    log-error "Error: Unable to create error log file $ERROR_LOG"
    exit 1
fi

# Variables
TP=/dev/stune/top-app/uclamp.max
CP=/dev/cpuset
ML=/sys/module
WT=/proc/sys/vm/watermark_boost_factor
KL=/proc/sys/kernel
VM=/proc/sys/vm
MG=/sys/kernel/mm/lru_gen
BT=$(getprop ro.boot.bootdevice)
BL=/dev/blkio
SCHED_PERIOD="$((6 * 1000 * 1000))"

# Info
log-trt "Starting TRT MIMK-143 | Yoshine Yuria"
log-trt "Build Date: 17/12/2023"
log-trt "Author: @Rui_Tachibana_Desu"
log-trt "Device: $(getprop ro.product.system.model)"
log-trt "Brand: $(getprop ro.product.system.brand)"
log-trt "Kernel: $(uname -r)"
log-trt "Rom build type: $(getprop ro.system.build.type)"
log-trt "Android Version: $(getprop ro.system.build.version.release)"

# Grouping Tweak
log-trt ""
log-trt "Enabling Sched Auto Group..."
write "$KL/sched_autogroup_enabled" 1
log-trt "Done."
log-trt ""

#Ram Tweak
log-trt "Applying Ram Tweaks"
sleep 0.5
write "$VM/vfs_cache_pressure" 50
write "$VM/stat_interval" 15
write "$VM/compaction_proactiveness" 0
write "$VM/page-cluster" 0
write "$VM/swappiness" 100
write "$VM/dirty_ratio" 30
log-trt "Applied Ram Tweaks"
log-trt ""

# Mglru
log-trt "Checking if your kernel has mglru support..."
if [ -d "$MG" ]; then
    log-trt "Found it."
    log-trt "Tweaking it..."
    write "$MG/min_ttl_ms" 5000
    log-trt "Done."
    log-trt ""
else
    log-yakt "Your kernel doesn't support mglru :("
    log-trt "Aborting it..."
    log-trt ""
fi

# Set kernel.perf_cpu_time_max_percent to 10
log-trt "Applying tweak for perf_cpu_time_max_percent"
write "$KL/perf_cpu_time_max_percent" 10
log-trt "Done."
log-trt ""

# Disable some scheduler logs/stats
log-trt "Disabling some scheduler logs/stats"
if [ -e "$KL/sched_schedstats" ]; then
    write "$KL/sched_schedstats" 0
fi
write "$KL/printk" "0        0 0 0"
write "$KL/printk_devkmsg" "off"
for queue in /sys/block/*/queue
do
    write "$queue/iostats" 0
    write "$queue/nr_requests" 64
done
log-trt "Done."
log-trt ""

wait_for_boot
mount -o rw,remount /system
sleep 1
mount -o rw,remount /vendor
sleep 1
mount -o rw,remount /data
sleep 1
TweakDevice

TweakDevice(){
chipset_manufacturer=$(getprop ro.soc.manufacturer)

# Cek jika produsen chipset adalah MediaTek atau Snapdragon
if [ "$chipset_manufacturer" == "Mediatek" ]; then
    # Script untuk chipset MediaTek 
# Disable System Control

if [ -e /system/etc/sysctl.conf ]; then
  mount -o remount,rw /system;
  mv /system/etc/sysctl.conf /system/etc/sysctl.conf.bak;
  mount -o remount,ro /system;
fi;

# APPLY AFTER BOOT
wait_until_boot_complete() {
  while [[ "$(getprop sys.boot_completed)" != "1" ]]; do
    sleep 5
  done
}

wait_until_boot_complete

SC=/sys/class
SM=/sys/module

# Sungkem Dulu Mbod
chmod 777 $SC/power_supply/*/*
chmod 777 $SM/qpnp_smbcharger/*/*
chmod 777 $SM/dwc3_msm/*/*
chmod 777 $SM/phy_msm_usb/*/*

sleep 10

find /sys/devices/virtual/thermal -type f -exec chmod 000 {} +
sleep 1

#Bunuh Sensor Luwh
sleep 1

stop logd

sleep 10

for thermal in $(resetprop | awk -F '[][]' '/thermal/ {print $2}'); do
  if [[ $(resetprop "$thermal") == running ]] || [[ $(resetprop "$thermal") == restarting ]]; then
    stop "${thermal/init.svc.}"
    sleep 10
    resetprop -n "$thermal" stopped
  fi
done

sleep 10

find /sys/devices/virtual/thermal -type f -exec chmod 000 {} +
sleep 1
# Universal Thermal Disabler
echo 0 > /sys/class/thermal/thermal_zone*/mode
sleep 1

# Thermal Stop Setprop Methode
setprop init.svc.android.thermal-hal stopped
setprop init.svc.thermal stopped
setprop init.svc.thermal-managers stopped
setprop init.svc.thermal_manager stopped
setprop init.svc.thermal_mnt_hal_service stopped
setprop init.svc.thermal-engine stopped
setprop init.svc.mi-thermald stopped
setprop init.svc.thermalloadalgod stopped
setprop init.svc.thermalservice stopped
setprop init.svc.thermal-hal stopped
setprop init.svc.vendor.thermal-symlinks
setprop init.svc.android.thermal-hal stopped
setprop init.svc.vendor.thermal-hal stopped
setprop init.svc.thermal-manager stopped
setprop init.svc.vendor-thermal-hal-1-0 stopped
setprop init.svc.vendor.thermal-hal-1-0 stopped
setprop init.svc.vendor.thermal-hal-2-0.mtk stopped
setprop init.svc.vendor.thermal-hal-2-0 stopped
sleep 1

# Thermal Stop Semi-auto Methode
sleep 12
stop logd
sleep 1
stop vendor.thermal-engine
sleep 1
stop vendor.thermal_manager
sleep 1
stop vendor.thermal-manager
sleep 1
stop vendor.thermal-hal-2-0
sleep 1
stop vendor.thermal-symlinks
sleep 1
stop thermal_mnt_hal_service
sleep 1
stop thermal
sleep 1
stop mi_thermald
sleep 1
stop thermald
sleep 1
stop thermalloadalgod
sleep 1
stop thermalservice
sleep 1
stop sec-thermal-1-0
sleep 1
stop debug_pid.sec-thermal-1-0
sleep 1
stop thermal-engine
sleep 1
stop vendor.thermal-hal-1-0
sleep 1
stop android.thermal-hal
sleep 1
stop vendor-thermal-1-0
sleep 1
stop thermal-hal
sleep 1
stop android.thermal-hal
sleep 1

echo "0" > /sys/block/mmcblk0/queue/add_random
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0/queue/nomerges
echo "0" > /sys/block/mmcblk0/queue/rotational
echo "1" > /sys/block/mmcblk0/queue/rq_affinity
echo "320" > /sys/block/mmcblk0/queue/nr_requests
echo "512" > /sys/block/mmcblk0/queue/read_ahead_kb

echo "0" > /sys/block/sda/queue/add_random
echo "0" > /sys/block/sda/queue/iostats
echo "0" > /sys/block/sda/queue/nomerges
echo "0" > /sys/block/sda/queue/rotational
echo "1" > /sys/block/sda/queue/rq_affinity
echo "320" > /sys/block/sda/queue/nr_requests
echo "512" > /sys/block/sda/queue/read_ahead_kb

echo "0" > /sys/block/sdb/queue/add_random
echo "0" > /sys/block/sdb/queue/iostats
echo "0" > /sys/block/sdb/queue/nomerges
echo "0" > /sys/block/sdb/queue/rotational
echo "1" > /sys/block/sdb/queue/rq_affinity
echo "320" > /sys/block/sdb/queue/nr_requests
echo "512" > /sys/block/sdb/queue/read_ahead_kb

echo "0" > /sys/block/sdc/queue/add_random
echo "0" > /sys/block/sdc/queue/iostats
echo "0" > /sys/block/sdc/queue/nomerges
echo "0" > /sys/block/sdc/queue/rotational
echo "1" > /sys/block/sdc/queue/rq_affinity
echo "320" > /sys/block/sdc/queue/nr_requests
echo "512" > /sys/block/sdc/queue/read_ahead_kb 

#CPU Governor
chmod 0644 /sys/devices/system/cpu/cpufreq/policy0/scaling_governor
chmod 0644 /sys/devices/system/cpu/cpufreq/policy6/scaling_governor 
chmod 0644 /sys/devices/system/cpu/cpufreq/schedutil/*
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy0/scaling_governor 
echo "schedutil" > /sys/devices/system/cpu/cpufreq/policy6/scaling_governo

# proc mali
echo "always_on" > /sys/class/misc/mali0/device/power_policy
echo "1" > /proc/mali/always_on

#CPU Luwh Biar Ngatcheng
#Mulai Eksekusi
sleep 1m

#Penggunaan Aplikasi Latar Belakang User (Mengurangi Penggunaan Daya, Dapat Memengaruhi Pengunduhan Latar Belakang, Tetapi Tetap Lancar )
back=/dev/cpuset/background/cpus
echo "0-1" > $back
#Penggunaan Aplikasi Di Latar Belakang Sistem ( Mengurangi Penggunaan CPU Untuk Menghemat Daya )
system=/dev/cpuset/system-background/cpus
echo "0-2" > $system
#Penggunaan Aplikasi Di Latar Depan
for=/dev/cpuset/foreground/cpus
echo "0-7" > $for
#Penggunaan Aplikasi Di Latar Utama
top=/dev/cpuset/top-app/cpus
echo "0-7" > $top

#Menyesuaikan Penggunaan CPU
#Aplikasi di latar depan ( 100% Akan Menggunakan CPU )
fore=/dev/stune/foreground/schedtune.boost
echo "10" > $fore
#Penggunaan Aplikasi Di Latar Depan
topp=/dev/stune/top-app/schedtune.boost
echo "0" > $topp
#Penggunaan Aplikasi Latar Belakang ( Mengurangi Penggunaan Baterai )
back=/dev/stune/background/schedtune.boost
echo "0" > $back

#Optimasi Core
#Large Core Naik Bagus Untuk Performa, Tidak Bagus Untuk Mengurangi Penggunaan Baterai
dow=/proc/sys/kernel/sched_downmigrate
echo "40 40" > $dow
#Little Cluster Naik Untuk Performa Yang Lebih Bagus, Bagus Untuk Konsumsi Penggunaan Baterai
sch=/proc/sys/kernel/sched_upmigrate
echo "60 60" > $sch
#Teknologi cpu boost dapat diartikan sebagai overclocking otomatis, yang secara otomatis dapat meng-overclock CPU ketika frekuensi utama tidak mencukupi. 
#Kecuali 0, yang berarti mematikan boost, tiga level lainnya secara fleksibel mengontrol berbagai kecenderungan konsumsi daya dan kinerja. 
#0 berarti mati secara default, 1 berarti QCOM menyarankan agar aplikasi dihidupkan ulang secara dingin untuk pertama kalinya, dan menyetel tanda selama 2 detik. 
#2 berarti QCOM disarankan untuk digunakan dalam skenario seperti menggeser layar, menekan tombol, dan sistem bangun 
#3 berarti QCOM merekomendasikan pengaturan 2-15 detik untuk aplikasi yang dimulai lebih dari 2 detik, seperti game, booting
#Level Tinggi, Brt Penggunaan Daya Juga Lebih Besar
boost=/proc/sys/kernel/sched_boost
echo "1" > $boost

#Atur Suhu Baterai Ke 15°C
#Cegah Pemicu Untuk Drop FPS  150=15℃
#Beberapa Sistem Mungkin Tidak Dapat Dimodifikasi
temp=/sys/class/power_supply/bms/temp
echo 150 > $temp



#----------------output log----------------#
#Log location
log=/storage/emulated/0/TRT.log
#Output log content
echo "
              TR-Tweak ( @Rui_Tachibana_Desu )
    *CPU core performance optimization output log*" > $log
echo "
    *Modification of the Number of CPU Cores*" >> $log
echo "• The User's Background Application Core:"  `cat $back` >> $log
echo "• The Background Application Core of the System:"  `cat $system` >> $log
echo "• Front-end Application Core:"  `cat $for` >> $log
echo "• Apps Displayed On Top:"  `cat $top` >> $log
echo "
    *Adjust cpu aggressiveness percentage %* " >> $log
echo "• Foreground Application:"  `cat $fore` >> $log
echo "• Apps Displayed On Top:"  `cat $topp` >> $log
echo "• Applications in the User Background:"  `cat $back` >> $log
echo "
    *Core Allocation Optimization*" >> $log
echo "• Large Core Allocation:"  `cat $dow` >> $log
echo "• Small Core Allocation:"  `cat $sch` >> $log
echo "• CPU Boss Allocation:"  `cat $boost` >> $log
echo "
    ▸ Current Battery Temperature:  `cat $temp`
           （150÷10=15°C）" >> $log

#I/O
echo "noop" > /sys/block/mmcblk0/queue/scheduler
echo "noop" > /sys/block/sda/queue/scheduler
echo "noop" > /sys/block/sdb/queue/scheduler
echo "noop" > /sys/block/sdc/queue/scheduler

# Disable multi core power saving
mcps="/sys/devices/system/cpu/sched_mc_power_savings"
if [[ -e "$mcps" ]]; then
  write "0" $mcps
fi

# Limit thermal ignore
glti="/proc/gpufreq/gpufreq_limited_thermal_ignore"
if [[ -e "$glti" ]]; then
  write "1" $glti
fi

# Gaming Touch For Kangaroox
if [[ -e "/sys/devices/virtual/touch/touch_dev/bump_sample_rate" ]]; then
  write "1" /sys/devices/virtual/touch/touch_dev/bump_sample_rate
fi

# Enable Fast Charging Rate
if [[ -e "/sys/kernel/fast_charge/force_fast_charge" ]]; then
  write "1" /sys/kernel/fast_charge/force_fast_charge
fi

#Touchscreen
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;

#write /proc/sys/kernel/sched_lib_name "com.miHoYo., com.activision., UnityMain, libunity.so, libil2cpp.so"
write /proc/sys/kernel/sched_lib_name "com.miHoYo., com.activision., com.epicgames, com.dts., UnityMain, libunity.so, libil2cpp.so, libmain.so, libcri_vip_unity.so, libopus.so, libxlua.so, libUE4.so, libAsphalt9.so, libnative-lib.so, libRiotGamesApi.so, libResources.so, libagame.so, libapp.so, libflutter.so, libMSDKCore.so, libFIFAMobileNeon.so, libUnreal.so, libEOSSDK.so, libcocos2dcpp.so"
write /proc/sys/kernel/sched_lib_mask_force "240"

#write /proc/sys/kernel/sched_lib_mask_force 255
echo "240" > /proc/sys/kernel/sched_lib_mask_force
sleep 1

#Kernel Mu Lagi Biar Touch Ngatcheng
echo "55" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "24000" > /proc/sys/kernel/perf_event_max_sample_rate
echo "570" > /proc/sys/kernel/perf_event_mlock_kb
echo "95" > /proc/sys/kernel/sched_downmigrate
echo "160" > /proc/sys/kernel/sched_group_upmigrate

#Kernelmu Biar Kaga Panik Kek Elu 
echo 0 > "/proc/sys/kernel/panic"
echo 0 > "/proc/sys/kernel/panic_on_oops"
echo 0 > "/proc/sys/kernel/panic_on_rcu_stall"
echo 0 > "/proc/sys/kernel/panic_on_warn"
echo 0 > "/proc/sys/kernel/softlockup_panic"
echo 0 > "/sys/module/kernel/parameters/panic"
echo 0 > "/sys/module/kernel/parameters/panic_on_warn"
echo 0 > "/sys/module/kernel/parameters/panic_on_oops"

# Zram
ZRAMSIZE=0
swapoff /dev/block/zram0 > /dev/null 2>&1
echo "1" > /sys/block/zram0/reset
echo "0" > /sys/block/zram0/disksize
echo "$ZRAMSIZE" > /sys/block/zram0/disksize
mkswap /dev/block/zram0 > /dev/null 2>&1
swapon /dev/block/zram0 > /dev/null 2>&1

#CAF Tweak
if [[ -d "/sys/module/cpu_boost" ]]
then
	write "/sys/module/cpu_boost/parameters/input_boost_freq" 0:1800000
	write "/sys/module/cpu_boost/parameters/input_boost_ms" 230
fi

#Thermal Mu
echo "-1" > /sys/class/thermal/thermal_message/sconfig
echo Y > /sys/module/smb_lib/parameters/skip_thermal

#Disable CPU Hotplug
for i in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl ; do
    chmod 666 $i/enable
	echo 0 > $i/enable
	chmod 444 $i/enable
done

#Disable GPU Throttling
for i in /sys/class/kgsl/kgsl-3d0 ; do

	echo 0 > $i/thermal_pwrlevel
    echo 0 > $i/throttling 
    echo 0 > $i/max_pwrlevel
    echo 0 > $i/perfcounter
    echo 1 > $i/force_clk_on
    echo 0 > $i/force_bus_on
    echo 1 > $i/force_rail_on
    echo 1 > $i/force_no_nap
    echo 1 > $i/bus_split

done

#Biar Hemat Baterai Anjenk
echo "N" > /sys/module/workqueue/parameters/power_efficient
echo "N" > /sys/module/battery_saver/parameters/enabled
echo "N" > /sys/module/workqueue/parameters/disable_numa
echo "1" > /sys/devices/system/cpu/perf/enable 

#PRM
echo 0 > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo 0 > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps
echo Y > /sys/module/lpm_levels/parameters/sleep_disabled
echo 3 > /proc/sys/vm/drop_caches

# Power Saving
chmod 755 /sys/module/workqueue/parameters/power_efficient
echo 'N' > /sys/module/workqueue/parameters/power_efficient
chmod 664 /sys/module/workqueue/parameters/power_efficient

# Better Idling
echo '0-3' > /dev/cpuset/restricted/cpus

# Battery Saving
echo 'freeze mem' > /sys/power/state
echo 's2idle [deep]' > /sys/power/mem_sleep

#Fsync
chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo 'N' > /sys/module/sync/parameters/fsync_enabled

#Parameter
echo 0 > /sys/module/rmnet_data/parameters/rmnet_data_log_level
echo 0 > /sys/kernel/debug/rpm_log
echo 0 > /d/tracing/tracing_on

#Script
nohup sh $MODDIR/script/shellscript > /dev/null &
#nohup sh $MODDIR/script/shellscript1 > /dev/null &
#nohup sh $MODDIR/script/shellscript2 > /dev/null &
#nohup sh $MODDIR/script/shellscript3 > /dev/null &

for i in $(find /sys/ -name debug_mask); do
echo "0" > $i;
done
for i in $(find /sys/ -name debug_level); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ce); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ue); do
echo "0" > $i;
done
for i in $(find /sys/ -name enable_event_log); do
echo "0" > $i;
done
for i in $(find /sys/ -name log_ecn_error); do
echo "0" > $i;
done
for i in $(find /sys/ -name snapshot_crashdumper); do
echo "0" > $i;
done

for i in /sys/devices/virtual/block/*/queue/iosched; do
  echo "0" > $i/low_latency;
done;

if [ -e "/sys/module/xhci_hcd/parameters/wl_divide" ]; then
echo "N" > /sys/module/xhci_hcd/parameters/wl_divide
fi

# Script for delete apps
function delete()
{
  if pm list packages -e 2>/dev/null | grep $1; then
  su -c pm uninstall --user 0 $1
  fi
}

#???
delete com.miui.analytics # Deleting background logs
delete com.miui.msa.global # Miui System Ads = MSA
delete com.facebook.services # Uselles facebook services
delete com.facebook.system # Uselles facebook services
delete com.facebook.appmanager # Uselles facebook services
delete com.android.traceur # Deleting background logs

# Better rendering speed
change_task_cgroup "surfaceflinger" "" "cpuset"
change_task_cgroup "surfaceflinger" "" "stune"
change_task_cgroup "android.hardware.graphics.composer" "" "cpuset"
change_task_cgroup "android.hardware.graphics.composer" "" "stune"

upgrade_miui() {
# Check if we're running MIUI
  [[ "$(getprop ro.miui.ui.version.name)" ]] && miui=true
  
  [[ "$miui" == "true" ]] && {
  # Cpu sets
  write "0-2,4-7" /dev/cpuset/foreground/cpus
  }

  nr_cores=$(cat /sys/devices/system/cpu/possible | awk -F "-" '{print $2}')
  nr_cores=$((nr_cores+1))

  [[ "$nr_cores" -eq "0" ]] && nr_cores=1

  [[ "$miui" == "true" ]] && [[ "$nr_cores" == "8" ]] && {
  resetprop persist.sys.miui.sf_cores "4-7"
  resetprop persist.sys.miui_animator_sched.bigcores "4-7"
  }

  [[ "$miui" == "true" ]] && [[ "$nr_cores" == "6" ]] && {
  resetprop persist.sys.miui.sf_cores "0-5"
  resetprop persist.sys.miui_animator_sched.bigcores "2-5"
  }

  [[ "$miui" == "true" ]] && [[ "$nr_cores" == "4" ]] && {
  resetprop persist.sys.miui.sf_cores "0-3"
  resetprop persist.sys.miui_animator_sched.bigcores "0-3"
  }
}

# Apply settings for miui
upgrade_miui

# Stop services
su -c stop tcpdump
su -c stop cnss_diag
su -c stop statsd
su -c stop traced
su -c stop miuibooster
su -c stop vendor.perfservice
