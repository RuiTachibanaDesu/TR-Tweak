#!/system/bin/sh

# Sync to data in the rare case a device crashes
sync

# Path
BASEDIR=/data/adb/modules/TR-Tweak
LOG=/storage/emulated/0/TRT/trtweak.log

# Governor for cpu4-7
GOV47=custom

# Functions
read_file(){
  if [[ -f $1 ]]; then
    if [[ ! -r $1 ]]; then
      chmod +r "$1"
    fi
    cat "$1"
  else
    echo "File $1 not found"
  fi
}

enable_thermal_service()
{
  start android.thermal-hal
  start debug_pid.sec-thermal-1-0
  start mi_thermald
  start thermal
  start thermal-engine
  start thermal_mnt_hal_service
  start thermal-hal
  start thermald
  start thermalloadalgod
  start thermalservice
  start sec-thermal-1-0
  start vendor.thermal-hal-1-0
  start vendor.semc.hardware.thermal-1-0
  start vendor-thermal-1-0
  start vendor.thermal-engine
  start vendor.thermal-manager
  start vendor.thermal-hal-2-0
  start vendor.thermal-symlinks
  start vendor.thermal-manager
  
  sleep 1
  
  setprop init.svc.android.thermal-hal start
  setprop init.svc.thermal start
  setprop init.svc.thermal-managers start
  setprop init.svc.thermal_manager stopped
  setprop init.svc.thermal_mnt_hal_service start
  setprop init.svc.thermal-engine start
  setprop init.svc.mi-thermald start
  setprop init.svc.thermalloadalgod start
  setprop init.svc.thermalservice start
  setprop init.svc.thermal-hal stopped start
  setprop init.svc.vendor.thermal-symlinks start
  setprop init.svc.android.thermal-hal start
  setprop init.svc.vendor.thermal-hal start
  setprop init.svc.thermal-manager start
  setprop init.svc.vendor-thermal-hal-1-0 start
  setprop init.svc.vendor.thermal-hal-1-0 start
  setprop init.svc.vendor.thermal-hal-2-0.mtk start
  setprop init.svc.vendor.thermal-hal-2-0 start
}

downclock_cpu()
{
  #cpu4
   fb4=$(read_file "/sys/devices/system/cpu/cpu4/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed '/^$/d' | tail -n 4 | head -n 1)
   echo "$fb4" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
  #cpu5
   fb5=$(read_file "/sys/devices/system/cpu/cpu5/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed '/^$/d' | tail -n 4 | head -n 1)
   echo "$fb5" > /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
  #cpu6
   fb6=$(read_file "/sys/devices/system/cpu/cpu6/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed '/^$/d' | tail -n 4 | head -n 1)
   echo "$fb6" > /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
  #cpu7
   fb7=$(read_file "/sys/devices/system/cpu/cpu7/cpufreq/scaling_available_frequencies" | tr " " "\n" | sort -n | sed '/^$/d' | tail -n 4 | head -n 1)
   echo "$fb7" > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
}

schedutil_tunables_bal03()
{
for eas in /sys/devices/system/cpu/cpu[0,1,2,3]/cpufreq/schedutil
do
  echo "99" > $eas/hispeed_load
  echo "0" > $eas/up_rate_limit_us
  echo "0" > $eas/down_rate_limit_us
  echo "1" > $eas/pl
done
}

schedutil_tunables_bal47()
{
for eas in /sys/devices/system/cpu/cpu[4,5,6,7]/cpufreq/schedutil
do
  echo "99" > $eas/hispeed_load
  echo "0" > $eas/up_rate_limit_us
  echo "0" > $eas/down_rate_limit_us
  echo "1" > $eas/pl
done
}

disable2core()
{
  chmod 644 /sys/devices/system/cpu/cpu0/online
  echo "1" > /sys/devices/system/cpu/cpu0/online
  chmod 444 /sys/devices/system/cpu/cpu0/online
  chmod 644 /sys/devices/system/cpu/cpu1/online
  echo "1" > /sys/devices/system/cpu/cpu1/online
  chmod 444 /sys/devices/system/cpu/cpu1/online
  chmod 644 /sys/devices/system/cpu/cpu2/online
  echo "1" > /sys/devices/system/cpu/cpu2/online
  chmod 444 /sys/devices/system/cpu/cpu2/online
  chmod 644 /sys/devices/system/cpu/cpu3/online
  echo "0" > /sys/devices/system/cpu/cpu3/online
  chmod 444 /sys/devices/system/cpu/cpu3/online
  chmod 644 /sys/devices/system/cpu/cpu4/online
  echo "1" > /sys/devices/system/cpu/cpu4/online
  chmod 444 /sys/devices/system/cpu/cpu4/online
  chmod 644 /sys/devices/system/cpu/cpu5/online
  echo "1" > /sys/devices/system/cpu/cpu5/online
  chmod 444 /sys/devices/system/cpu/cpu5/online
  chmod 644 /sys/devices/system/cpu/cpu6/online
  echo "1" > /sys/devices/system/cpu/cpu6/online
  chmod 444 /sys/devices/system/cpu/cpu6/online
  chmod 644 /sys/devices/system/cpu/cpu7/online
  echo "0" > /sys/devices/system/cpu/cpu7/online
  chmod 444 /sys/devices/system/cpu/cpu7/online
}

# Enable Thermal
#enable_thermal_service

# Cpu core control 
#disable2core
#downclock_cpu

# Governor
##cpu0-3
  for gov in /sys/devices/system/cpu/cpu[0,1,2,3]/cpufreq
  do
    echo "schedutil" > $gov/scaling_governor
  done
##cpu4-7
  for gov in /sys/devices/system/cpu/cpu[4,5,6,7]/cpufreq
  do
    echo "$GOV47" > $gov/scaling_governor
  done

# Schedutil tunables
schedutil_tunables_bal03
#schedutil_tunables_bal47

# Fs break time
echo "50" > /proc/sys/fs/lease-break-time

#Disable GPU Throttling
for i in /sys/class/kgsl/kgsl-3d0 ; do

	echo 0 > $i/thermal_pwrlevel
    echo 0 > $i/throttling 
    echo 0 > $i/max_pwrlevel
    echo 0 > $i/perfcounter
    echo 1 > $i/force_clk_on
    echo 0 > $i/force_bus_on
    echo 1 > $i/force_rail_on
    echo 1 > $i/force_no_nap
    echo 1 > $i/bus_split

done

#Biar Hemat Baterai Anjenk
echo "N" > /sys/module/workqueue/parameters/power_efficient
echo "N" > /sys/module/battery_saver/parameters/enabled
echo "N" > /sys/module/workqueue/parameters/disable_numa
echo "1" > /sys/devices/system/cpu/perf/enable 

# Power Saving
chmod 755 /sys/module/workqueue/parameters/power_efficient
echo 'N' > /sys/module/workqueue/parameters/power_efficient
chmod 664 /sys/module/workqueue/parameters/power_efficient

# Better Idling
echo '0-3' > /dev/cpuset/restricted/cpus

# Battery Saving
echo 'freeze mem' > /sys/power/state
echo 's2idle [deep]' > /sys/power/mem_sleep

#Mulai Eksekusi
sleep 1m

#Penggunaan Aplikasi Latar Belakang User (Mengurangi Penggunaan Daya, Dapat Memengaruhi Pengunduhan Latar Belakang, Tetapi Tetap Lancar )
back=/dev/cpuset/background/cpus
echo "0-1" > 
#Penggunaan Aplikasi Di Latar Belakang Sistem ( Mengurangi Penggunaan CPU Untuk Menghemat Daya )
system=/dev/cpuset/system-background/cpus
echo "0-2" > 
#Penggunaan Aplikasi Di Latar Depan
for=/dev/cpuset/foreground/cpus
echo "0-7" > 
#Penggunaan Aplikasi Di Latar Utama
top=/dev/cpuset/top-app/cpus
echo "0-7" > 

#Menyesuaikan Penggunaan CPU
#Aplikasi di latar depan ( 100% Akan Menggunakan CPU )
fore=/dev/stune/foreground/schedtune.boost
echo "10" > 
#Penggunaan Aplikasi Di Latar Depan
topp=/dev/stune/top-app/schedtune.boost
echo "0" > 
#Penggunaan Aplikasi Latar Belakang ( Mengurangi Penggunaan Baterai )
back=/dev/stune/background/schedtune.boost
echo "0" > 

#Optimasi Core
#Large Core Naik Bagus Untuk Performa, Tidak Bagus Untuk Mengurangi Penggunaan Baterai
dow=/proc/sys/kernel/sched_downmigrate
echo "40 40" > 
#Little Cluster Naik Untuk Performa Yang Lebih Bagus, Bagus Untuk Konsumsi Penggunaan Baterai
sch=/proc/sys/kernel/sched_upmigrate
echo "60 60" > 
#Teknologi cpu boost dapat diartikan sebagai overclocking otomatis, yang secara otomatis dapat meng-overclock CPU ketika frekuensi utama tidak mencukupi. 
#Kecuali 0, yang berarti mematikan boost, tiga level lainnya secara fleksibel mengontrol berbagai kecenderungan konsumsi daya dan kinerja. 
#0 berarti mati secara default, 1 berarti QCOM menyarankan agar aplikasi dihidupkan ulang secara dingin untuk pertama kalinya, dan menyetel tanda selama 2 detik. 
#2 berarti QCOM disarankan untuk digunakan dalam skenario seperti menggeser layar, menekan tombol, dan sistem bangun 
#3 berarti QCOM merekomendasikan pengaturan 2-15 detik untuk aplikasi yang dimulai lebih dari 2 detik, seperti game, booting
#Level Tinggi, Brt Penggunaan Daya Juga Lebih Besar
boost=/proc/sys/kernel/sched_boost
echo "0" > 

#Atur Suhu Baterai Ke 15°C
#Cegah Pemicu Untuk Drop FPS  150=15℃
#Beberapa Sistem Mungkin Tidak Dapat Dimodifikasi
temp=/sys/class/power_supply/bms/temp
echo 150 > 

# Set balance
setprop trtweak.mode balance
echo " •> Balance mode activated at $(date "+%H:%M:%S")" >> $LOG

# Report
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ ❄️ Balance Mode... ] /g' "$BASEDIR/module.prop"
am start -a android.intent.action.MAIN -e toasttext "❄️ Balance Mode..." -n bellavita.toast/.MainActivity

exit 0