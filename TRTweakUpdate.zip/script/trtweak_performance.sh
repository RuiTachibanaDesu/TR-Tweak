#!/system/bin/sh

# Sync to data in the rare case a device crashes
sync

# Path
BASEDIR=/data/adb/modules/TR-Tweak
LOG=/storage/emulated/0/TR-Tweak/trtweak.log

# Functions
read_file(){
  if [[ -f $1 ]]; then
    if [[ ! -r $1 ]]; then
      chmod +r "$1"
    fi
    cat "$1"
  else
    echo "File $1 not found"
  fi
}

disable_thermal_service()
{
  stop vendor.thermal-engine
  stop vendor.thermal_manager
  stop vendor.thermal-manager
  stop vendor.thermal-hal-2-0
  stop vendor.thermal-symlinks
  stop thermal_mnt_hal_service
  stop thermal
  stop mi_thermald
  stop thermald
  stop thermalloadalgod
  stop thermalservice
  stop sec-thermal-1-0
  stop debug_pid.sec-thermal-1-0
  stop thermal-engine
  stop vendor.thermal-hal-1-0
  stop android.thermal-hal
  stop vendor-thermal-1-0
  stop thermal-hal
  stop android.thermal-hal
  
  sleep 1

  setprop init.svc.android.thermal-hal stopped
  setprop init.svc.thermal stopped
  setprop init.svc.thermal-managers stopped
  setprop init.svc.thermal_manager stopped
  setprop init.svc.thermal_mnt_hal_service stopped
  setprop init.svc.thermal-engine stopped
  setprop init.svc.mi-thermald stopped
  setprop init.svc.thermalloadalgod stopped
  setprop init.svc.thermalservice stopped
  setprop init.svc.thermal-hal stopped
  setprop init.svc.vendor.thermal-symlinks
  setprop init.svc.android.thermal-hal stopped
  setprop init.svc.vendor.thermal-hal stopped
  setprop init.svc.thermal-manager stopped
  setprop init.svc.vendor-thermal-hal-1-0 stopped
  setprop init.svc.vendor.thermal-hal-1-0 stopped
  setprop init.svc.vendor.thermal-hal-2-0.mtk stopped
  setprop init.svc.vendor.thermal-hal-2-0 stopped
  
#kill sensor
sleep 10

for thermal in $(resetprop | awk -F '[][]' '/thermal/ {print $2}'); do
  if [[ $(resetprop "$thermal") == running ]] || [[ $(resetprop "$thermal") == restarting ]]; then
    stop "${thermal/init.svc.}"
    sleep 10
    resetprop -n "$thermal" stopped
  fi
done

sleep 10

find /sys/devices/virtual/thermal -type f -exec chmod 000 {} +
sleep 1

# Universal Thermal Disabler
echo 0 > /sys/class/thermal/thermal_zone*/mode

}

restore_cpu_clock()
{
  #cpu4
   fp4=$(read_file "/sys/devices/system/cpu/cpu4/cpufreq/cpuinfo_max_freq")
   echo "$fp4" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_max_freq
  #cpu5
   fp5=$(read_file "/sys/devices/system/cpu/cpu5/cpufreq/cpuinfo_max_freq")
   echo "$fp5" > /sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq
  #cpu6
   fp6=$(read_file "/sys/devices/system/cpu/cpu6/cpufreq/cpuinfo_max_freq")
   echo "$fp6" > /sys/devices/system/cpu/cpu6/cpufreq/scaling_max_freq
  #cpu7
   fp7=$(read_file "/sys/devices/system/cpu/cpu7/cpufreq/cpuinfo_max_freq")
   echo "$fp7" > /sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq
}

schedutil_tunables_game03()
{
for eas in /sys/devices/system/cpu/cpu[0,1,2,3]/cpufreq/schedutil
do
  echo "80" > $eas/hispeed_load
  echo "0" > $eas/up_rate_limit_us
  echo "0" > $eas/down_rate_limit_us
  echo "1" > $eas/pl
done
}

schedutil_tunables_game47()
{
for eas in /sys/devices/system/cpu/cpu[4,5,6,7]/cpufreq/schedutil
do
  echo "80" > $eas/hispeed_load
  echo "0" > $eas/up_rate_limit_us
  echo "0" > $eas/down_rate_limit_us
  echo "1" > $eas/pl
done
}

enableallcore()
{
  chmod 644 /sys/devices/system/cpu/cpu0/online
  echo "1" > /sys/devices/system/cpu/cpu0/online
  chmod 444 /sys/devices/system/cpu/cpu0/online
  chmod 644 /sys/devices/system/cpu/cpu1/online
  echo "1" > /sys/devices/system/cpu/cpu1/online
  chmod 444 /sys/devices/system/cpu/cpu1/online
  chmod 644 /sys/devices/system/cpu/cpu2/online
  echo "1" > /sys/devices/system/cpu/cpu2/online
  chmod 444 /sys/devices/system/cpu/cpu2/online
  chmod 644 /sys/devices/system/cpu/cpu3/online
  echo "1" > /sys/devices/system/cpu/cpu3/online
  chmod 444 /sys/devices/system/cpu/cpu3/online
  chmod 644 /sys/devices/system/cpu/cpu4/online
  echo "1" > /sys/devices/system/cpu/cpu4/online
  chmod 444 /sys/devices/system/cpu/cpu4/online
  chmod 644 /sys/devices/system/cpu/cpu5/online
  echo "1" > /sys/devices/system/cpu/cpu5/online
  chmod 444 /sys/devices/system/cpu/cpu5/online
  chmod 644 /sys/devices/system/cpu/cpu6/online
  echo "1" > /sys/devices/system/cpu/cpu6/online
  chmod 444 /sys/devices/system/cpu/cpu6/online
  chmod 644 /sys/devices/system/cpu/cpu7/online
  echo "1" > /sys/devices/system/cpu/cpu7/online
  chmod 444 /sys/devices/system/cpu/cpu7/online
}

# Disable Thermal
#disable_thermal_service

# Cpu core control
#enableallcore
#restore_cpu_clock

# Governor
##cpu0-3
  for gov in /sys/devices/system/cpu/cpu[0,1,2,3]/cpufreq
  do
    echo "schedutil" > $gov/scaling_governor
  done
##cpu4-7
  for gov in /sys/devices/system/cpu/cpu[4,5,6,7]/cpufreq
  do
    echo "schedutil" > $gov/scaling_governor
  done

# Schedutil tunables
schedutil_tunables_game03
schedutil_tunables_game47

# Schedtune top-app boost
echo "69" > /dev/stune/top-app/schedtune.boost

# Fs break time
echo "5" > /proc/sys/fs/lease-break-time

#Thermal Mu
echo "-1" > /sys/class/thermal/thermal_message/sconfig
echo Y > /sys/module/smb_lib/parameters/skip_thermal

#Disable GPU Throttling
for i in /sys/class/kgsl/kgsl-3d0 ; do

	echo 0 > $i/thermal_pwrlevel
    echo 0 > $i/throttling 
    echo 0 > $i/max_pwrlevel
    echo 0 > $i/perfcounter
    echo 1 > $i/force_clk_on
    echo 0 > $i/force_bus_on
    echo 1 > $i/force_rail_on
    echo 1 > $i/force_no_nap
    echo 1 > $i/bus_split

done


#Mulai Eksekusi
sleep 1m

#Penggunaan Aplikasi Latar Belakang User (Mengurangi Penggunaan Daya, Dapat Memengaruhi Pengunduhan Latar Belakang, Tetapi Tetap Lancar )
back=/dev/cpuset/background/cpus
echo "0-1" > 
#Penggunaan Aplikasi Di Latar Belakang Sistem ( Mengurangi Penggunaan CPU Untuk Menghemat Daya )
system=/dev/cpuset/system-background/cpus
echo "0-2" > 
#Penggunaan Aplikasi Di Latar Depan
for=/dev/cpuset/foreground/cpus
echo "0-7" > 
#Penggunaan Aplikasi Di Latar Utama
top=/dev/cpuset/top-app/cpus
echo "0-7" > 

#Menyesuaikan Penggunaan CPU
#Aplikasi di latar depan ( 100% Akan Menggunakan CPU )
fore=/dev/stune/foreground/schedtune.boost
echo "10" > 
#Penggunaan Aplikasi Di Latar Depan
topp=/dev/stune/top-app/schedtune.boost
echo "0" > 
#Penggunaan Aplikasi Latar Belakang ( Mengurangi Penggunaan Baterai )
back=/dev/stune/background/schedtune.boost
echo "0" > 

#Optimasi Core
#Large Core Naik Bagus Untuk Performa, Tidak Bagus Untuk Mengurangi Penggunaan Baterai
dow=/proc/sys/kernel/sched_downmigrate
echo "40 40" > 
#Little Cluster Naik Untuk Performa Yang Lebih Bagus, Bagus Untuk Konsumsi Penggunaan Baterai
sch=/proc/sys/kernel/sched_upmigrate
echo "60 60" > 
#Teknologi cpu boost dapat diartikan sebagai overclocking otomatis, yang secara otomatis dapat meng-overclock CPU ketika frekuensi utama tidak mencukupi. 
#Kecuali 0, yang berarti mematikan boost, tiga level lainnya secara fleksibel mengontrol berbagai kecenderungan konsumsi daya dan kinerja. 
#0 berarti mati secara default, 1 berarti QCOM menyarankan agar aplikasi dihidupkan ulang secara dingin untuk pertama kalinya, dan menyetel tanda selama 2 detik. 
#2 berarti QCOM disarankan untuk digunakan dalam skenario seperti menggeser layar, menekan tombol, dan sistem bangun 
#3 berarti QCOM merekomendasikan pengaturan 2-15 detik untuk aplikasi yang dimulai lebih dari 2 detik, seperti game, booting
#Level Tinggi, Brt Penggunaan Daya Juga Lebih Besar
boost=/proc/sys/kernel/sched_boost
echo "1" > 

#Atur Suhu Baterai Ke 15°C
#Cegah Pemicu Untuk Drop FPS  150=15℃
#Beberapa Sistem Mungkin Tidak Dapat Dimodifikasi
temp=/sys/class/power_supply/bms/temp
echo 150 > 

sleep 1
# Disable Apps (AOSP)
su -c "pm disable com.google.android.as.oss"
su -c "pm disable com.google.android.apps.turbo"
su -c "pm disable com.google.android.projection.gearhead"
su -c "pm disable com.stevesoltys.seedvault"
su -c "pm disable com.android.emergency"
su -c "pm disable com.android.bips"
su -c "pm disable com.android.printspooler"
su -c "pm disable com.android.bookmarkprovider"
su -c "pm disable com.android.cellbroadcastreceiver.module"
su -c "pm disable com.google.audio.hearing.visualization.accessibility.scribe"
su -c "pm disable com.google.android.apps.safetyhub"
su -c "pm disable com.google.android.marvin.talkback"
su -c "pm disable com.google.android.apps.helprtc"
su -c "pm disable com.google.android.apps.work.clouddpc"
su -c "pm disable com.google.android.printservice.recommendation"
su -c "pm disable com.google.android.as"
su -c "pm disable oneos.logcat"
su -c "pm disable com.android.printspooler"
su -c "pm disable-user --user 0 com.google.android.apps.wellbeing"
su -c "pm disable com.google.android.apps.turbo.services/com.google.android.apps.turbo.services.health.ModuleInitializerService"
su -c "pm disable-user --user 0 com.google.android.apps.gsa.intelligence"
su -c "pm disable com.google.android.ambientcompute"
su -c "pm disable org.lineageos.profiles"
su -c "pm disable com.android.cellbroadcastreceiver.module"
su -c "pm disable com.android.emergency"
su -c "pm disable io.chaldeaprjkt.gamespace"
su -c "pm disable com.caf.fmradio"
su -c "pm disable org.lineageos.recorder"
su -c "pm disable com.crdroid.updater"

# FORCE CLOSE A PARTICULAR APP IN THE BACKGROUND
su -c "am force-stop com.facebook.katana"
su -c "am force-stop com.instagram.android"
su -c "am force-stop com.google.android.gm"
su -c "am force-stop com.vanced.android.youtube"

sleep 1
#Disable Apps ( MIUI )
su -c pm disable com.xiaomi.ab
su -c pm disable com.xiaomi.aiasst.service
su -c pm disable com.xiaomi.gamecenter.sdk.service
su -c pm disable com.xiaomi.joyose
su -c pm disable com.xiaomi.mi_connect_service
su -c pm disable com.xiaomi.micloud.sdk
su -c pm disable com.xiaomi.migameservice
su -c pm disable com.xiaomi.miplay_client
su -c pm disable com.xiaomi.mircs
su -c pm disable com.xiaomi.mirror
su -c pm disable com.xiaomi.payment
su -c pm disable com.xiaomi.powerchecker
su -c pm disable com.xiaomi.simactivate.service
su -c pm disable com.xiaomi.xmsf
su -c pm disable com.xiaomi.xmsfkeeper
su -c pm disable com.milink.service
su -c pm disable com.miui.analytics
su -c pm disable com.miui.audioeffect
su -c pm disable com.miui.audiomonitor
su -c pm disable com.miui.bugreport
su -c pm disable com.miui.cit
su -c pm disable com.miui.cloudbackup
su -c pm disable com.miui.cloudservice
su -c pm disable com.miui.cloudservice.sysbase
su -c pm disable com.miui.contentcatcher
su -c pm disable com.miui.daemon
su -c pm disable com.miui.hybrid
su -c pm disable com.miui.hybrid.accessory
su -c pm disable com.miui.maintenancemode
su -c pm disable com.miui.micloudsync
su -c pm disable com.miui.miservice
su -c pm disable com.miui.mishare.connectivity
su -c pm disable com.miui.misound
su -c pm disable com.miui.nextpay
su -c pm disable com.miui.personalassistant
su -c pm disable com.miui.phrase
su -c pm disable com.miui.smsextra
su -c pm disable com.miui.systemAdSolution
su -c pm disable com.miui.touchassistant
su -c pm disable com.miui.translation.kingsoft
su -c pm disable com.miui.translation.xmcloud
su -c pm disable com.miui.translation.youdao
su -c pm disable com.miui.translationservice
su -c pm disable com.miui.voiceassist
su -c pm disable com.miui.voicetrigger
su -c pm disable com.miui.vsimcore
su -c pm disable com.miui.wmsvc
su -c pm disable com.mobiletools.systemhelper
su -c pm disable com.android.bookmarkprovider
su -c pm disable com.android.browser
su -c pm disable com.android.calendar
su -c pm disable com.android.carrierdefaultapp
su -c pm disable com.android.cellbroadcastservice
su -c pm disable com.android.companiondevicemanager
su -c pm disable com.android.dreams.basic
su -c pm disable com.android.dreams.phototable
su -c pm disable com.android.emergency
su -c pm disable com.android.htmlviewer
su -c pm disable com.android.ons
su -c pm disable com.android.printspooler
su -c pm disable com.android.quicksearchbox
su -c pm disable com.android.simappdialog
su -c pm disable com.android.stk
su -c pm disable com.android.traceur
su -c pm disable com.bsp.catchlog
su -c pm disable com.google.android.configupdater
su -c pm disable com.google.android.marvin.talkback
su -c pm disable com.google.android.onetimeinitializer
su -c pm disable com.google.android.printservice.recommendation
su -c pm disable com.miui.msa.global
su -c pm disable com.google.android.feedback
su -c pm disable com.mfashiongallery.emag
su -c pm disable com.miui.huanji
su -c pm disable com.miui.newmidrive

# Set perf
setprop trtweak.mode performance
echo " •> Performance mode activated at $(date "+%H:%M:%S")" >> $LOG

# Report
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ 🔥 Performance Mode... ] /g' "$BASEDIR/module.prop"
am start -a android.intent.action.MAIN -e toasttext "🔥 Performance Mode..." -n bellavita.toast/.MainActivity

exit 0