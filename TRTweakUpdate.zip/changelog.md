- IDK

#3.0
- Add String For Parameter Kernel
- Add Gamelist

#3.1
- Add Block List App For Better Gheyming
- Fix WiFi And Data Can't On In KSU And Apatch

#3.2
- Hehe Gomen

#3.3
- Fix opt
- Fix Installer 

#4.0
- Add Termux Option

#5.0
- Remove Ai
- Back To Fully Performance
- Remove More Options On Installer
- Zram By Default Rom And Kernel
- Added More Option On Termux Mode
- Still Use String On Ai Version But This Not Ai Version
- U Can Add More Performance On Option In Installer
- DONATE ANJENK BIAR DEV MU GAK GILA

#7.55
- Add AI For Game, You Can Add Game In Termux, Just Typing su ( Enter ) TRT
- Fix For AI Game
- Fix Bypass Charging