- IDK

#1.0
- For ksu user I'm not sure whether it works or notI'm not sure if it works  
#1.1
- Added More Option
- Fixed Option Changing GPU
