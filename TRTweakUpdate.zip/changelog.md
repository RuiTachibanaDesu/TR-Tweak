- IDK

#1.0
- For ksu user I'm not sure whether it works or notI'm not sure if it works  

#1.1
- Added More Option
- Fixed Option Changing GPU

#1.2
- Remove Fast Charging ( Some Device Not Working )
- Added More Tweak For Kernel
- Added Tweak For Ram
- Added More Tweak For Better Experience Gaming

#1.3
- Added Back Force Fast Charging
- Added Bypass Charging

#1.3.1
- Fix Minor Bugs

#1.4
- Fix Major Bug On Installer
- Added Auto Cut Charger
- Added More Tweak For Better Performance

#1.4.1
- Fixed Problem with Auto Cut Charger