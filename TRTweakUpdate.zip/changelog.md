- IDK

#1.0
- For ksu user I'm not sure whether it works or notI'm not sure if it works  

#1.1
- Added More Option
- Fixed Option Changing GPU

#1.2
- Remove Fast Charging ( Some Device Not Working )
- Added More Tweak For Kernel
- Added Tweak For Ram
- Added More Tweak For Better Experience Gaming