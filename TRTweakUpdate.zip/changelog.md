- IDK

#3.0
- Add String For Parameter Kernel
- Add Gamelist

#3.1
- Add Block List App For Better Gheyming
- Fix WiFi And Data Can't On In KSU And Apatch

#3.2
- Hehe Gomen

#3.3
- Fix opt
- Fix Installer 