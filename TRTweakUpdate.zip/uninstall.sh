#!/system/bin/sh

# Remove swapfile
if test -f "/data/swap"; then
  swapoff /data/swap
  rm -f /data/swap
fi

# Delete TRTweak dir
rm -rf /storage/emulated/0/trtweak

# Uninstall toast
pm uninstall bellavita.toast

if [ -f $INFO ]; then
  while read LINE; do
    if [ "$(echo -n $LINE | tail -c 1)" == "~" ]; then
      continue
    elif [ -f "$LINE~" ]; then
      mv -f $LINE~ $LINE
    else
      rm -f $LINE
      while true; do
        LINE=$(dirname $LINE)
        [ "$(ls -A $LINE 2>/dev/null)" ] && break 1 || rm -rf $LINE
      done
    fi
  done < $INFO
  rm -f $INFO
fi