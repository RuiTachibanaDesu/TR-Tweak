#!/sbin/sh
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true
# Set what you want to display when installing your module
MODNAME=`grep_prop name $TMPDIR/module.prop`
MODVER=`grep_prop version $TMPDIR/module.prop`
DV=`grep_prop author $TMPDIR/module.prop`

Device=`getprop ro.product.device`
Model=`getprop ro.product.model`
Brand=`getprop ro.product.brand`
Time=$(date "+%d, %b - %H:%M %Z")

ui_print " "
ui_print "----------------------------------------------------------------"
ui_print " "
ui_print " Module info: "
ui_print " • Author          : $DV "
ui_print " • Name            : $MODNAME"
ui_print " • Codename        : $MODVER"
ui_print " • Status          : Public release "
ui_print " • Powered         : Vendora"
ui_print " "
ui_print " Device info:"
ui_print " • Brand           : $Brand "
ui_print " • Model           : $Model "
ui_print " • Processor       : $Device "
ui_print " "
ui_print "----------------------------------------------------------------"
sleep 0.5
ui_print " Removed Cache, Please Wait..."
           rm -rf /cache/dalvik-cache
           rm -rf /data/cache
           rm -rf /data/dalvik-cache
ui_print " Remove Cache Done..."
ui_print "----------------------------------------------------------------"
sleep 2
ui_print " Running FStrim, Please Wait... "
           fstrim -v /data
           fstrim -v /system
           fstrim -v /cache
ui_print " FStrim Is Done..."
ui_print "----------------------------------------------------------------"
sleep 2
ui_print "- Installing $MODNAME!"
ui_print "- Install Successful at $Time !!"


# Wifi bonding
wifibonding_enable() {
[ -x "$(which magisk)" ] && MIRRORPATH=$(magisk --path)/.magisk/mirror || unset MIRRORPATH
array=$(find /system /vendor /product /system_ext -name WCNSS_qcom_cfg.ini)
for CFG in $array
do
[[ -f $CFG ]] && [[ ! -L $CFG ]] && {
SELECTPATH=$CFG
mkdir -p `dirname $MODPATH$CFG`
cp -af $MIRRORPATH$SELECTPATH $MODPATH$SELECTPATH
sed -i '/gChannelBondingMode24GHz=/d;/gChannelBondingMode5GHz=/d;/gForce1x1Exception=/d;/sae_enabled=/d;s/^END$/gChannelBondingMode24GHz=1\ngChannelBondingMode5GHz=1\ngForce1x1Exception=0\nsae_enabled=1\nEND/g' $MODPATH$SELECTPATH
}
done
[[ -z $SELECTPATH ]] && abort "- Installation FAILED. Your device didn't support WCNSS_qcom_cfg.ini." || { mkdir -p $MODPATH/system; mv -f $MODPATH/vendor $MODPATH/system/vendor; mv -f $MODPATH/product $MODPATH/system/product; mv -f $MODPATH/system_ext $MODPATH/system/system_ext;}
}

# Universal GMS Doze by gloeyisk
# open source loving GL-DP and all contributors;
# Patches Google Play services app and its background processes to be able using battery optimization
#
# Patch the XML and place the modified one to the original directory
gms_doze_installer() {
ui_print "- Patching XML files"
GMS0="\"com.google.android.gms"\"
STR1="allow-in-power-save package=$GMS0"
STR2="allow-in-data-usage-save package=$GMS0"
NULL="/dev/null"
ui_print "- Finding system XML"
SYS_XML="$(
SXML="$(find /system_ext/* /system/* /product/* \
/vendor/* -type f -iname '*.xml' -print)"
for S in $SXML; do
  if grep -qE "$STR1|$STR2" $ROOT$S 2> $NULL; then
    echo "$S"
  fi
done
)"

PATCH_SX() {
for SX in $SYS_XML; do
  mkdir -p "$(dirname $MODPATH$SX)"
  cp -af $ROOT$SX $MODPATH$SX
  ui_print "  Patching: $SX"
  sed -i "/$STR1/d;/$STR2/d" $MODPATH/$SX
done

# Merge patched files under /system dir
for P in product vendor; do
  if [ -d $MODPATH/$P ]; then
    mkdir -p $MODPATH/system/$P
    mv -f $MODPATH/$P $MODPATH/system/
  fi
done
}

# Search and patch any conflicting modules (if present)
# Search conflicting XML files
MOD_XML="$(
MXML="$(find /data/adb/* -type f -iname "*.xml" -print)"
for M in $MXML; do
  if grep -qE "$STR1|$STR2" $M; then
    echo "$M"
  fi
done
)"

PATCH_MX() {
ui_print "- Finding conflicting XML"
for MX in $MOD_XML; do
  MOD="$(echo "$MX" | awk -F'/' '{print $5}')"
  ui_print "  $MOD: $MX"
  sed -i "/$STR1/d;/$STR2/d" $MX
done
}

# Search and patch any conflicting modules (if present)
# Search conflicting XML files
conflict1=$(xml=$(find /data/adb -iname "*.xml");for i in $xml; do if grep -q 'allow-unthrottled-location package="com.google.android.gms"' $i 2>/dev/null; then echo "$i";fi; done)
conflict2=$(xml=$(find /data/adb -iname "*.xml");for i in $xml; do if grep -q 'allow-ignore-location-settings package="com.google.android.gms"' $i 2>/dev/null; then echo "$i";fi; done)
for i in $conflict1 $conflict2
do
search=$(echo "$i" | sed -e 's/\// /g' | awk '{print $4}')
ui_print "- Conflicting modules detected"
ui_print "   $search"
sed -i '/allow-unthrottled-location package="com.google.android.gms"/d;/allow-ignore-location-settings package="com.google.android.gms"/d' $i
done

# Find and patch conflicting XML
PATCH_SX && PATCH_MX
}

# Dex2oat opt
dex2oat_enable() {
[[ "$IS64BIT" == "true" ]] && mv -f "$MODPATH/system/bin/dex2oat_opt64" "$MODPATH/system/bin/dex2oat_opt" && rm -f $MODPATH/system/bin/dex2oat_opt32 || mv -f "$MODPATH/system/bin/dex2oat_opt32" "$MODPATH/system/bin/dex2oat_opt" && rm -f $MODPATH/system/bin/dex2oat_opt64
}


#GPU Composition
#SkiaGL
apply_DYN_GPU_setting_SkiaGL() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/DYN/*' -d $TMPDIR >&2
}

apply_MDP_GPU_setting_SkiaGL() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/MDP/*' -d $TMPDIR >&2
}

apply_C2D_GPU_setting_SkiaGL() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/C2D/*' -d $TMPDIR >&2
}

apply_GPU_GPU_setting_SkiaGL() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/GPU/*' -d $TMPDIR >&2
}

apply_SKIP_GPU_setting_SkiaGL() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaGL/SKIP/*' -d $TMPDIR >&2
}
    

#SkiaVK
apply_DYN_GPU_setting_SkiaVK() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/DYN/*' -d $TMPDIR >&2
}
apply_MDP_GPU_setting_SkiaVK() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/MDP/*' -d $TMPDIR >&2
}

apply_C2D_GPU_setting_SkiaVK() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/C2D/*' -d $TMPDIR >&2
}

apply_GPU_GPU_setting_SkiaVK() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/GPU/*' -d $TMPDIR >&2
}

apply_SKIP_GPU_setting_SkiaVK() {
    unzip -oj "$ZIPFILE" 'Renderer/SkiaVK/SKIP/*' -d $TMPDIR >&2
}
    

#OpenGL
apply_DYN_GPU_setting_OpenGL() {
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/DYN/*' -d $TMPDIR >&2
}

apply_MDP_GPU_setting_OpenGL() {
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/MDP/*' -d $TMPDIR >&2
}

apply_C2D_GPU_setting_OpenGL() {
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/C2D/*' -d $TMPDIR >&2
}

apply_GPU_GPU_setting_OpenGL() {
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/GPU/*' -d $TMPDIR >&2
}

apply_SKIP_GPU_setting_OpenGL() {
    unzip -oj "$ZIPFILE" 'Renderer/OpenGL/SKIP/*' -d $TMPDIR >&2
}
    

#Vulkan
apply_DYN_GPU_setting_Vulkan() {
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/DYN/*' -d $TMPDIR >&2
}

apply_MDP_GPU_setting_Vulkan() {
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/MDP/*' -d $TMPDIR >&2
}

apply_C2D_GPU_setting_Vulkan() {
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/C2D/*' -d $TMPDIR >&2
}

apply_GPU_GPU_setting_Vulkan() {
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/GPU/*' -d $TMPDIR >&2
}

apply_SKIP_GPU_setting_Vulkan() {
    unzip -oj "$ZIPFILE" 'Renderer/Vulkan/SKIP/*' -d $TMPDIR >&2
}


#Skip
Skip() {
    unzip -oj "$ZIPFILE" 'Renderer/Skip/*' -d $TMPDIR >&2
}


# Run addons
if [ "$(ls -A $MODPATH/addon/*/install.sh 2>/dev/null)" ]; then
  ui_print "- Running Addons"
  for i in $MODPATH/addon/*/install.sh; do
    ui_print "  Running $(echo $i | sed -r "s|$MODPATH/addon/(.*)/install.sh|\1|")..."
    . $i
  done
fi

ui_print "" 
ui_print "  Volume Key Selector to select options:"
ui_print "  1) More balance mode options"
ui_print "  2) Disable thermal engine"
ui_print "  3) Deepsleep enhancer"
ui_print "  4) Zram size"
ui_print "  5) Swap ram size"
ui_print "  6) GMS doze"
ui_print "  7) Wifi bonding"
ui_print "  8) Dex2oat optimizer"
ui_print "  9) Built-in magisk busybox"
ui_print "  10) GPU Rendering"
ui_print "  11) GPU Composition"
ui_print "  12) Install Or Remove Module"
ui_print ""
ui_print "  Button Function:"
ui_print "  Press Volume up (+) to switch options "
ui_print "  Press Volume down (-) to select "
ui_print ""
sleep 3

# Balance mode option
ui_print "  ⚠️More balance mode options..."
ui_print "     1. Default"
ui_print "     2. Downclock frequency cpu4-7"
ui_print "     3. Disable 2 cpu core"
ui_print "     4. Powersave governor cpu4-7"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
A=1
while true; do
    ui_print "    $A"
    if $VKSEL; then
        A=$((A + 1))
    else
        break
    fi
    if [ $A -gt 4 ]; then
        A=1
    fi
done
ui_print "    Selected: $A"
case $A in
    1 ) TEXT1="Default"; sed -i '/GOV47=custom/s/.*/GOV47=schedutil/' $MODPATH/script/trtweak_balance.sh; sed -i '/#schedutil_tunables_bal47/s/.*/schedutil_tunables_bal47/' $MODPATH/script/trtweak_balance.sh;;
    2 ) TEXT1="Downclock frequency cpu4-7"; sed -i '/GOV47=custom/s/.*/GOV47=schedutil/' $MODPATH/script/trtweak_balance.sh; sed -i '/#schedutil_tunables_bal47/s/.*/schedutil_tunables_bal47/' $MODPATH/script/trtweak_balance.sh; sed -i '/#downclock_cpu/s/.*/downclock_cpu/' $MODPATH/script/trtweak_balance.sh; sed -i '/#restore_cpu_clock/s/.*/restore_cpu_clock/' $MODPATH/script/trtweak_performance.sh;;
    3 ) TEXT1="Disable 2 cpu core"; sed -i '/GOV47=custom/s/.*/GOV47=schedutil/' $MODPATH/script/trtweak_balance.sh; sed -i '/#schedutil_tunables_bal47/s/.*/schedutil_tunables_bal47/' $MODPATH/script/trtweak_balance.sh; sed -i '/#disable2core/s/.*/disable2core/' $MODPATH/script/trtweak_balance.sh; sed -i '/#enableallcore/s/.*/enableallcore/' $MODPATH/script/trtweak_performance.sh;;
    4 ) TEXT1="Powersave governor cpu4-7"; sed -i '/GOV47=custom/s/.*/GOV47=powersave/' $MODPATH/script/trtweak_balance.sh;;
esac
ui_print "    $TEXT1"
ui_print ""

# Disable thermal
ui_print "  ⚠️Disable thermal engine..."
ui_print "     1. Yes"
ui_print "     2. No"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
B=1
while true; do
    ui_print "    $B"
    if $VKSEL; then
        B=$((B + 1))
    else
        break
    fi
    if [ $B -gt 2 ]; then
        B=1
    fi
done
ui_print "    Selected: $B"
case $B in
    1 ) TEXT2="Yes"; sed -i '/#enable_thermal_service/s/.*/enable_thermal_service/' $MODPATH/script/trtweak_balance.sh; sed -i '/#disable_thermal_service/s/.*/disable_thermal_service/' $MODPATH/script/trtweak_performance.sh;;
    2 ) TEXT2="No";;
esac
ui_print "    $TEXT2"
ui_print ""
ui_print " Please Wait... "
sleep 2

    if [[ $TEXT2 == "Yes" ]]; then
  ui_print " Thermals have been uploaded "
  ui_print ""
  ui_print " Resolution of conflicting thermal modules "
  ui_print ""
  sleep 2
  
  [[ -d "${moddir}/TRT" ]] && {
  ui_print " You have TR-Tweak is installed, delete old module after reboot."
  touch $moddir/TRT/disable
  ui_print "  Disabled"
  ui_print ""
  }

  [[ -d "${moddir}/TR-Tweak" ]] && {
  ui_print " You have TR-Tweak is installed, delete old module after reboot."
  touch $moddir/TRT/disable
  ui_print "  Disabled"
  ui_print ""
  }

  [[ -d "${moddir}/smooth_thermals" ]] && {
  ui_print " You have Smooth Thermal is installed, disabled it to avoid conflicts."
  touch $moddir/smooth_thermals/disable
  ui_print " Disabled"
  ui_print ""
  }
  
  [[ -d "${moddir}/ZyCMiThermald" ]] && {
  ui_print " You have Mi Thermald disabler is installed, disabled it to avoid conflicts."
  touch $moddir/ZyCMiThermald/disable
  ui_print " Disabled"
  ui_print ""
  }
  
  [[ -d "${moddir}/adreno-team-exclusive-thermals" ]] && {
  ui_print " You have Adreno thermals is installed, disabled it to avoid conflicts."
  touch $moddir/adreno-team-exclusive-thermals/disable
  ui_print " Disabled"
  ui_print ""
  }
  
  [[ -d "${moddir}/SD865" ]] && {
  ui_print " You have No junk thermals is installed, disabled it to avoid conflicts."
  touch $moddir/SD865/disable
  ui_print "  Disabled"
  ui_print ""
  }
  
  [[ -d "${moddir}/SD855" ]] && {
  ui_print " You have Thermal unlocker 855 is installed, disabled it to avoid conflicts."
  touch $moddir/SD855/disable
  ui_print "  Disabled"
  ui_print ""
  }
  
  [[ -d "${moddir}/SD860" ]] && {
  ui_print " You have Thermal-X Expert is installed, disabled it to avoid conflicts."
  touch $moddir/SD860/disable
  ui_print "  Disabled"
  ui_print ""
  }
  
  [[ -d "${moddir}/thermods_rvns" ]] && {
  ui_print " You have Thermode by rawens is installed, disabled it to avoid conflicts."
  touch $moddir/thermods_rvns/disable
  ui_print "  Disabled"
  ui_print ""
  }
  
  [[ -d "${moddir}/tengine" ]] && {
  ui_print " You have T Engine is installed, disabled it to avoid conflicts."
  touch $moddir/tengine/disable
  ui_print "  Disabled"
  ui_print ""
  }

elif [[ $TEXT2 == "No" ]]; then
  rm -rf "$MODPATH/system/vendor"
fi

sleep 1

# Deepsleep enhance 
ui_print ""
ui_print "  ⚠️Deepsleep enhance Mode..."
ui_print "     1. Default(use default deepsleep from your device)"
ui_print "     2. Light"
ui_print "     3. Moderate"
ui_print "     4. High"
ui_print "     5. Extreme"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
C=1
while true; do
    ui_print "    $C"
    if $VKSEL; then
        C=$((C + 1))
    else
        break
    fi
    if [ $C -gt 5 ]; then
        C=1
    fi
done
ui_print "    Selected: $C"
case $C in
    1 ) TEXT3="Default"; sed -i '/#dozemode/s/.*/doze_default/' $MODPATH/service.sh;;
    2 ) TEXT3="Light"; sed -i '/#dozemode/s/.*/doze_light/' $MODPATH/service.sh;;
    3 ) TEXT3="Moderate"; sed -i '/#dozemode/s/.*/doze_moderate/' $MODPATH/service.sh;;
    4 ) TEXT3="High"; sed -i '/#dozemode/s/.*/doze_high/' $MODPATH/service.sh;;
    5 ) TEXT3="Extreme"; sed -i '/#dozemode/s/.*/doze_extreme/' $MODPATH/service.sh;;
esac
ui_print "    $TEXT3"
ui_print ""

# Zram
ui_print "  ⚠️Zram size..."
ui_print "     1. Default(using default zram from device)"
ui_print "     2. Disable"
ui_print "     3. 1024MB"
ui_print "     4. 1536MB"
ui_print "     5. 2048MB"
ui_print "     6. 2560MB"
ui_print "     7. 3072MB"
ui_print "     8. 4096MB"
ui_print "     9. 5120MB"
ui_print "     10. 6144MB"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
D=1
while true; do
    ui_print "    $D"
    if $VKSEL; then
        D=$((D + 1))
    else
        break
    fi
    if [ $D -gt 10 ]; then
        D=1
    fi
done
ui_print "    Selected: $D"
case $D in
    1 ) TEXT4="Default";;
    2 ) TEXT4="Disable"; sed -i '/#change_zram/s/.*/disable_zram/' $MODPATH/service.sh;;
    3 ) TEXT4="1024MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=1025M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    4 ) TEXT4="1536MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=1537M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    5 ) TEXT4="2048MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=2049M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    6 ) TEXT4="2560MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=2561M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    7 ) TEXT4="3072MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=3073M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    8 ) TEXT4="4096MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=4097M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    9 ) TEXT4="5120MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=5121M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
    10 ) TEXT4="6144MB"; sed -i '/ZRAMSIZE=0/s/.*/ZRAMSIZE=6145M/' $MODPATH/service.sh; sed -i '/#change_zram/s/.*/change_zram/' $MODPATH/service.sh;;
esac
ui_print "    $TEXT4"
ui_print ""

# Swap ram
ui_print "  ⚠️Swap RAM size..."
ui_print "     1. Disable"
ui_print "     2. 1024MB"
ui_print "     3. 1536MB"
ui_print "     4. 2048MB"
ui_print "     5. 2560MB"
ui_print "     6. 3072MB"
ui_print "     7. 4096MB"
ui_print "     8. 5120MB"
ui_print "     9. 6144MB"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
E=1
while true; do
    ui_print "    $E"
    if $VKSEL; then
        E=$((E + 1))
    else
        break
    fi
    if [ $E -gt 9 ]; then
        E=1
    fi
done
ui_print "    Selected: $E"
case $E in
    1 ) TEXT5="Disable";;
    2 ) TEXT5="1024MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=1048576/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    3 ) TEXT5="1536MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=1572864/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    4 ) TEXT5="2048MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=2097152/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    5 ) TEXT5="2560MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=2621440/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    6 ) TEXT5="3072MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=3145728/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    7 ) TEXT5="4096MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=4194304/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    8 ) TEXT5="5120MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=5242880/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
    9 ) TEXT5="6144MB"; sed -i '/SWAPSIZE=0/s/.*/SWAPSIZE=6291456/' $MODPATH/service.sh; sed -i '/#change_swap/s/.*/change_swap/' $MODPATH/service.sh;;
esac
ui_print "    $TEXT5"
ui_print ""

# GMS doze
ui_print "  ⚠️GMS Doze..."
ui_print "     1. Enable"
ui_print "     2. Disable"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
F=1
while true; do
    ui_print "    $F"
    if $VKSEL; then
        F=$((F + 1))
    else
        break
    fi
    if [ $F -gt 2 ]; then
        F=1
    fi
done
ui_print "    Selected: $F"
case $F in
    1 ) TEXT6="Enable"; setprop trtweak.install.gmsdoze 1; sed -i '/#gms_doze_patch/s/.*/gms_doze_patch/' $MODPATH/post-fs-data.sh; sed -i '/#gms_doze_patch/s/.*/gms_doze_patch/' $MODPATH/post-fs-data.sh; sed -i '/#gms_doze_enable/s/.*/gms_doze_enable/' $MODPATH/service.sh;;
    2 ) TEXT6="Disable"; setprop trtweak.install.gmsdoze 0;;
esac
ui_print "    $TEXT6"
ui_print ""

# Wifi bonding
ui_print "  ⚠️Wifi Bonding..."
ui_print "     1. Enable"
ui_print "     2. Disable"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
G=1
while true; do
    ui_print "    $G"
    if $VKSEL; then
        G=$((G + 1))
    else
        break
    fi
    if [ $G -gt 2 ]; then
        G=1
    fi
done
ui_print "    Selected: $G"
case $G in
    1 ) TEXT7="Enable"; wifibonding_enable;;
    2 ) TEXT7="Disable";;
esac
ui_print "    $TEXT7"
ui_print ""

# Dex2oat optimizer
ui_print "  ⚠️Dex2oat optimizer..."
ui_print "     1. Enable"
ui_print "     2. Disable"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
H=1
while true; do
    ui_print "    $H"
    if $VKSEL; then
        H=$((H + 1))
    else
        break
    fi
    if [ $H -gt 2 ]; then
        H=1
    fi
done
ui_print "    Selected: $H"
case $H in
    1 ) TEXT8="Enable"; sed -i '/#dex2oat_opt_enable/s/.*/dex2oat_opt_enable/' $MODPATH/service.sh; dex2oat_enable;;
    2 ) TEXT8="Disable"; rm -rf $MODPATH/system/bin/dex2oat*; sed -i '/#x1/s/.*/sleep 45/' $MODPATH/service.sh;;
esac
ui_print "    $TEXT8"
ui_print ""

# Built-in busybox
ui_print "  ⚠️Built-in magisk busybox..."
ui_print "     1. Enable"
ui_print "     2. Disable"
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
I=1
while true; do
    ui_print "    $I"
    if $VKSEL; then
        I=$((I + 1))
    else
        break
    fi
    if [ $I -gt 2 ]; then
        I=1
    fi
done
ui_print "    Selected: $I"
case $I in
    1 ) TEXT9="Enable"; sed -i '/#install_busybox/s/.*/install_busybox/' $MODPATH/post-fs-data.sh;;
    2 ) TEXT9="Disable";;
esac
ui_print "    $TEXT9"
ui_print ""

# Function to customize the module during installation
    TMPDIR=/dev/tmp
    MOUNTPATH=/dev/magisk_img

    # Default permissions
    umask 022

    # echo before loading util_functions
	ui_print() { echo "$1"; }

	require_new_magisk() {
    ui_print "*******************************"
    ui_print " Please install Magisk v20.4+! "
    ui_print "*******************************"
    exit 1
}

	imageless_magisk() {
		[ $MAGISK_VER_CODE -gt 20400 ]
		return $?
}

    ##########################################################################################
    # Environment
    ##########################################################################################

    mount /data 2>/dev/null

    # Load utility functions
    if [ -f /data/adb/magisk/util_functions.sh ]; then
        . /data/adb/magisk/util_functions.sh
        NVBASE=/data/adb
    else
        require_new_magisk
    fi

    # Preperation for flashable zips
    setup_flashable

    # Mount partitions
    mount_partitions

    # Detect version and architecture
    api_level_arch_detect

    # Setup busybox and binaries
    $BOOTMODE && boot_actions || recovery_actions

    ##########################################################################################
    # Preparation
    ##########################################################################################

    # Extract common files
    unzip -oj "$ZIPFILE" module.prop uninstall.sh 'common/*' -d $TMPDIR >&2

    if imageless_magisk; then
        $BOOTMODE && MODDIRNAME=modules_update || MODDIRNAME=modules
        MODULEROOT=$NVBASE/$MODDIRNAME
    else
        $BOOTMODE && IMGNAME=magisk_merge.img || IMGNAME=magisk.img
        IMG=$NVBASE/$IMGNAME
        request_zip_size_check "$ZIPFILE"
        mount_magisk_img
        MODULEROOT=$MOUNTPATH
    fi

    MODID=$(grep_prop id $TMPDIR/module.prop)
    MODPATH=$MODULEROOT/$MODID
    
GpuCh() {
        # Skrip instalasi modul Magisk
ui_print " ⚠️ GPU Rendering" # Perubahan pada pesan selamat datang
ui_print "     1) SkiaGL "
ui_print "     2) SkiaVK "
ui_print "     3) OpenGL "
ui_print "     4) Vulkan "
ui_print "     5) Skip "
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
ui_print ""
ui_print "    Select:"
sleep 1

VKSEL=chooseport

J=1 # Menu utama
while true; do
    case $J in
        1 ) TEXT10="SkiaGL";;
        2 ) TEXT10="SkiaVK";;
        3 ) TEXT10="OpenGL";;
        4 ) TEXT10="Vulkan";;
        5 ) TEXT10="Skip";;
    esac
    ui_print "     $J - $TEXT10"
    if $VKSEL; then
        J=$((J + 1))
    else
        break
    fi
    if [ $J -gt 5 ]; then
        J=1
    fi
done

ui_print ""
ui_print "     Render GPU : $J - $TEXT10"

case $J in
    1 ) SkiaGL;;
    2 ) SkiaVK;;
    3 ) OpenGL;;
    4 ) Vulkan;;
    5 ) Skip;;
esac 
}

SkiaGL() {
VKSEL=chooseport

# Skrip untuk menu opsi GPU
ui_print " ⚠️ GPU Composition Options Menu" # Pesan selamat datang untuk menu baru
ui_print "     1) Core 2 Duo ( C2D ) -> ( CPU 25% - GPU 75% ) "
ui_print "     1) Multi Depth ( MDP ) -> ( 100% CPU Core ) "
ui_print "     1) Dynamic (DYN) ( CPU And GPU ) -> ( CPU 50% - GPU 50% ) "
ui_print "     1) GPU (GPU) GPU Only "
ui_print "     5) Skip ( Don't Change GPU Composition, But Use SkiaGL Render ) "
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
sleep 1

K=1 # Menu utama
while true; do
    case $K in
        1 ) TEXT11="Core 2 Duo (C2D) ( CPU 25% - GPU 75% )";;
        2 ) TEXT11="Multi Depth (MDP) ( 100% CPU Core )";;
        3 ) TEXT11="Dynamic (DYN) CPU And GPU ( CPU 50% - GPU 50% )";;
        4 ) TEXT11="GPU (GPU) GPU Only";;
        5 ) TEXT11="Skip ( Don't Change GPU Composition, But Use SkiaGL Render )";;
    esac
    ui_print "     $K - $TEXT11"
    if $VKSEL; then
        K=$((K + 1))
    else
        break
    fi
    if [ $K -gt 5 ]; then
        K=1
    fi
done

ui_print ""
ui_print "     You have selected: $K - $TEXT11 "

case $K in
    1) apply_DYN_GPU_setting_SkiaGL;;
    2) apply_MDP_GPU_setting_SkiaGL;;
    3) apply_C2D_GPU_setting_SkiaGL;;
    4) apply_GPU_GPU_setting_SkiaGL;;
    5) apply_SKIP_GPU_setting_SkiaGL;;
esac

}

SkiaVK() {
VKSEL=chooseport

# Skrip untuk menu opsi GPU
ui_print " ⚠️ GPU Composition Options Menu" # Pesan selamat datang untuk menu baru
ui_print "     1) Core 2 Duo ( C2D ) -> ( CPU 25% - GPU 75% ) "
ui_print "     1) Multi Depth ( MDP ) -> ( 100% CPU Core ) "
ui_print "     1) Dynamic (DYN) ( CPU And GPU ) -> ( CPU 50% - GPU 50% ) "
ui_print "     1) GPU (GPU) GPU Only "
ui_print "     5) Skip ( Don't Change GPU Composition, But Use SkiaVK Render ) "
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
sleep 1

K=1 # Menu utama
while true; do
    case $K in
        1 ) TEXT11="Core 2 Duo (C2D) ( CPU 25% - GPU 75% )";;
        2 ) TEXT11="Multi Depth (MDP) ( 100% CPU Core )";;
        3 ) TEXT11="Dynamic (DYN) CPU And GPU ( CPU 50% - GPU 50% )";;
        4 ) TEXT11="GPU (GPU) GPU Only";;
        5 ) TEXT11="Skip ( Don't Change GPU Composition, But Use SkiaVK Render )";;
    esac
    ui_print "     $K - $TEXT11"
    if $VKSEL; then
        K=$((K + 1))
    else
        break
    fi
    if [ $K -gt 5 ]; then
        K=1
    fi
done

ui_print ""
ui_print "     You have selected: $K - $TEXT11 "

case $K in
    1) apply_DYN_GPU_setting_SkiaVK;;
    2) apply_MDP_GPU_setting_SkiaVK;;
    3) apply_C2D_GPU_setting_SkiaVK;;
    4) apply_GPU_GPU_setting_SkiaVK;;
    5) apply_SKIP_GPU_setting_SkiaVK;;
esac

}

OpenGL() {
VKSEL=chooseport

# Skrip untuk menu opsi GPU
ui_print " ⚠️ GPU Composition Options Menu" # Pesan selamat datang untuk menu baru
ui_print "     1) Core 2 Duo ( C2D ) -> ( CPU 25% - GPU 75% ) "
ui_print "     1) Multi Depth ( MDP ) -> ( 100% CPU Core ) "
ui_print "     1) Dynamic (DYN) ( CPU And GPU ) -> ( CPU 50% - GPU 50% ) "
ui_print "     1) GPU (GPU) GPU Only "
ui_print "     5) Skip ( Don't Change GPU Composition, But Use OpenGL Render ) "
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
sleep 1

K=1 # Menu utama
while true; do
    case $K in
        1 ) TEXT11="Core 2 Duo (C2D) ( CPU 25% - GPU 75% )";;
        2 ) TEXT11="Multi Depth (MDP) ( 100% CPU Core )";;
        3 ) TEXT11="Dynamic (DYN) CPU And GPU ( CPU 50% - GPU 50% )";;
        4 ) TEXT11="GPU (GPU) GPU Only";;
        5 ) TEXT11="Skip ( Don't Change GPU Composition, But Use OpenGL Render )";;
    esac
    ui_print "     $K - $TEXT11"
    if $VKSEL; then
        K=$((K + 1))
    else
        break
    fi
    if [ $K -gt 5 ]; then
        K=1
    fi
done

ui_print ""
ui_print "     You have selected: $K - $TEXT11 "

case $K in
    1) apply_DYN_GPU_setting_OpenGl;;
    2) apply_MDP_GPU_setting_OpenGl;;
    3) apply_C2D_GPU_setting_OpenGl;;
    4) apply_GPU_GPU_setting_OpenGl;;
    5) apply_SKIP_GPU_setting_OpenGL;;
esac

}

Vulkan() {
VKSEL=chooseport

# Skrip untuk menu opsi GPU
ui_print " ⚠️ GPU Composition Options Menu" # Pesan selamat datang untuk menu baru
ui_print "     1) Core 2 Duo ( C2D ) -> ( CPU 25% - GPU 75% ) "
ui_print "     1) Multi Depth ( MDP ) -> ( 100% CPU Core ) "
ui_print "     1) Dynamic (DYN) ( CPU And GPU ) -> ( CPU 50% - GPU 50% ) "
ui_print "     1) GPU (GPU) GPU Only "
ui_print "     5) Skip ( Don't Change GPU Composition, But Use Vulkan Render ) "
ui_print ""
ui_print "     Press Volume up (+) to switch options "
ui_print "     Press Volume down (-) to select "
sleep 1

K=1 # Menu utama
while true; do
    case $K in
        1 ) TEXT11="Core 2 Duo (C2D) ( CPU 25% - GPU 75% )";;
        2 ) TEXT11="Multi Depth (MDP) ( 100% CPU Core )";;
        3 ) TEXT11="Dynamic (DYN) CPU And GPU ( CPU 50% - GPU 50% )";;
        4 ) TEXT11="GPU (GPU) GPU Only";;
        5 ) TEXT11="Skip ( Don't Change GPU Composition, But Use Vulkan Render )";;
    esac
    ui_print "     $K - $TEXT11"
    if $VKSEL; then
        K=$((K + 1))
    else
        break
    fi
    if [ $K -gt 5 ]; then
        K=1
    fi
done

ui_print ""
ui_print "     You have selected: $K - $TEXT11 "

case $K in
    1) apply_DYN_GPU_setting_Vulkan;;
    2) apply_MDP_GPU_setting_Vulkan;;
    3) apply_C2D_GPU_setting_Vulkan;;
    4) apply_GPU_GPU_setting_Vulkan;;
    5) apply_SKIP_GPU_setting_Vulkan;;
esac
}

InstallGki() {
VKSEL=chooseport

# Skrip instalasi modul Magisk
ui_print "     Install Module " # Perubahan pada pesan selamat datang
ui_print "     Remove Module "
ui_print ""
ui_print "     Volume up (+) to change selection"
ui_print "     Volume down (-) to decide"
sleep 1

L=1 # Menu utama
while true; do
    case $L in
        1 ) TEXT12="Install module";;
        2 ) TEXT12="Remove module";;
    esac
    ui_print "     $L - $TEXT12"
    if $VKSEL; then
        L=$((L + 1))
    else
        break
    fi
    if [ $L -gt 2 ]; then
        L=1
    fi
done

# Fungsi untuk menginstal modul
install_module() {
    CHECK2
    sleep 1
    # Check architecture
    if [ "$ARCH" != "arm" ] && [ "$ARCH" != "arm64" ] && [ "$ARCH" != "x86" ] && [ "$ARCH" != "x64" ]; then
        abort "! Unsupported platform: $ARCH"
    else
        ui_print "- Device platform: $ARCH"
    fi
    print_modname
}

# Fungsi untuk menghapus modul
remove_module() {
    cd /data/
    rm -rf /data/adb/modules/TR-Tweak
    sleep 2
    rm -rf /data/local/tmp/addon.sh

    ui_print "     - Module Telah Di Uninstall "
    ui_print "     - Penerapan akan dimulai setelah reboot."
    sleep 1
    exit
}

ui_print ""
ui_print "     You have selected: $L - $TEXT12 "

case $L in
    1 ) install_module1;;
    2 ) remove_module;;
esac
}

sleep 1

[[ -d "${moddir}/sqlite3stable" ]] && {
  ui_print " You have SQLite is installed, disabled, SQLite is already built into this module."
  touch $moddir/sqlite3stable/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/dex2oat_optimizer" ]] && {
  ui_print " You have Dex2oat Optimizer is installed, Dex2oat Optimizer is already built into this module."
  touch $moddir/dex2oat_optimizer/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/LIGHTNING" ]] && {
  ui_print " You have Lightning Module ( Trash ) is installed, Dex2oat Optimizer is already built into this module."
  touch $moddir/LIGHTNING/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/Godspeed" ]] && {
  ui_print " You have God Speed Module ( Gheymink ) is installed, disabled it to avoid conflicts."
  touch $moddir/Godspeed/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/FastCharging" ]] && {
  ui_print " You have FastCharging By Ryujin is installed, disabled it to avoid conflicts."
  touch $moddir/FastCharging/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/FCGreen" ]] && {
  ui_print " You have Fast Charger Green is installed, disabled it to avoid conflicts."
  touch $moddir/FCGreen/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/disable-thermal" ]] && {
  ui_print " You have Vendora Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/disable-thermal/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/naviaflower" ]] && {
  ui_print " You have Navia Project ( Meitektek ) Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/naviaflower/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/universal-gms-doze" ]] && {
  ui_print " You have Universal GMS Doze Tweaks is installed, Universal GMS Doze is already built into this module."
  touch $moddir/universal-gms-doze/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/injector" ]] && {
  ui_print " You have NFS injector Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/injector/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/BulletAimGyro" ]] && {
  ui_print " You have STRP x Bag Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/BulletAimGyro/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/PXT" ]] && {
  ui_print " You have Project Extreme Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/PXT/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/xload" ]] && {
  ui_print " You have Xload is installed, disabled it to avoid conflicts."
  touch $moddir/xload/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/Extreme" ]] && {
  ui_print " You have Extreme Gaming is installed, disabled it to avoid conflicts."
  touch $moddir/Extreme/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/GPUPerformanceXSeries" ]] && {
  ui_print " You have Gpu performance X series is installed, disabled it to avoid conflicts."
  touch $moddir/GPUPerformanceXSeries/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/SkiaGL-Default" ]] && {
  ui_print " You have SkiaGl Default is installed, disabled it to avoid conflicts."
  touch $moddir/SkiaGL-Default/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/SystemOptimization" ]] && {
  ui_print " You have Leudart Tweaks is installed, disabled it to avoid conflicts.."
  touch $moddir/SystemOptimization/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/onfiretweaks" ]] && {
  ui_print " You have 𝙊𝙣𝙁𝙞𝙧𝙚 𝙏𝙬𝙚𝙖𝙠𝙨 is installed, disabled it to avoid conflicts."
  touch $moddir/onfiretweaks/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/YAKT" ]] && {
  ui_print " You have YAKT is installed, disabled it to avoid conflicts."
  touch $moddir/YAKT/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/GPUTurboBoost" ]] && {
  ui_print " You have GPU Turbo Boost is installed, disabled it to avoid conflicts."
  touch $moddir/GPUTurboBoost/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/injector" ]] && {
  ui_print " You have Raven's injector is installed, disabled it to avoid conflicts."
  touch $moddir/injector/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/hotplug" ]] && {
  ui_print " You have Hotplug disabler is installed, disabled it to avoid conflicts."
  touch $moddir/hotplug/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/skiagloptimization" ]] && {
  ui_print " You have SkiaGl optimization is installed, disabled it to avoid conflicts."
  touch $moddir/skiagloptimization/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/GamersExtreme" ]] && {
  ui_print " You have Gaymers Extreme (trash) is installed, please remove it."
  touch $moddir/GamersExtreme/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/zeetaatweaks" ]] && {
  ui_print " You have Zeeta Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/zeetaatweaks/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/aosp_enhancer" ]] && {
  ui_print " You have AOSP Ecnhance is installed, disabled it to avoid conflicts."
  touch $moddir/aosp_enhancer/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/memeui_enhancer" ]] && {
  ui_print " You have MIUI Ecnhance is installed, disabled it to avoid conflicts."
  touch $moddir/memeui_enhancer/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/adrenotweaks" ]] && {
  ui_print " You have Adreno GPU Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/adrenotweaks/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/gpubuffercountkecil" ]] && {
  ui_print " You have GPU buffer count Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/gpubuffercountkecil/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/FrameBuffer" ]] && {
  ui_print " You have FrameBuffer is installed, disabled it to avoid conflicts."
  touch $moddir/FrameBuffer/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/ZTS" ]] && {
  ui_print " You have Zeeta Tweaks is installed, disabled it to avoid conflicts."
  touch $moddir/ZTS/disable
  ui_print " Disabled"
  ui_print ""
}

[[ -d "${moddir}/fkm_spectrum_injector" ]] && {
  ui_print " You have FKM Injector is installed, disabled it to avoid conflicts."
  touch $moddir/fkm_spectrum_injector/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/NetworkTweak" ]] && {
  ui_print " You have Network Tweak (trash) module is installed, disabled it to avoid conflicts."
  touch $moddir/NetworkTweak/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/MAGNETAR" ]] && {
  ui_print " You have Magnetar is installed, disabled it to avoid conflicts."
  touch $moddir/MAGNETAR/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/MAGNE" ]] && {
  ui_print " You have Magnetar is installed, disabled it to avoid conflicts."
  touch $moddir/MAGNE/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/FDE" ]] && {
  ui_print " You have FDE module is installed, disabled it to avoid conflicts."
  touch $moddir/FDE/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ "$(pm list package feravolt)" ]] && {
  ui_print " You have FDE.ai is installed, delete it to avoid conflicts."
  ui_print ""
}

[[ -d "${moddir}/ktweak" ]] && {
  ui_print " You have KTweak is installed, disabled it to avoid conflicts."
  touch $moddir/ktweak/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/lspeed" ]] && {
  ui_print " You have LSpeed is installed, disabled it to avoid conflicts."
  touch $moddir/lspeed/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ "$(pm list package magnetarapp)" ]] && {
  ui_print " You have Magnetar is installed, disabled it to avoid conflicts."
  ui_print ""
}

[[ -d "${moddir}/sqinjector" ]] && {
  ui_print " You have SQ Injector is installed, disabled it to avoid conflicts."
  touch $moddir/sqinjector/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/nexus" ]] && {
  ui_print " You have Nexus module is installed, disabled it to avoid conflicts."
  touch $moddir/nexus/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ -d "${moddir}/flushram" ]] && {
  ui_print " You have Flush RAM module is installed, disabled it to avoid conflicts."
  touch $moddir/flushram/disable
  ui_print "  Disabled"
  ui_print ""
}

[[ "$(pm list package nfsmanager)" ]] && {
  ui_print " You have NFS injector is installed, delete it to avoid conflicts."
  su -c pm disable com.nfs.nfsmanager
  ui_print "  Disabled app"
  ui_print ""
}

[[ "$(pm list package ktweak)" ]] && {
  ui_print " You have KTweak is installed, delete it to avoid conflicts."
  su -c pm disable com.draco.ktweak
  ui_print "  Disabled app"
  ui_print ""
}

[[ "$(pm list package lsandroid)" ]] && {
  ui_print " You have LSpeed is installed, delete it to avoid conflicts."
  su -c pm disable com.paget96.lsandroid
  ui_print "  Disabled app"
  ui_print ""
}

sleep 2
ui_print "  Your settings:"
ui_print "  1) More balance mode options : $TEXT1"
ui_print "  2) Disable thermal engine    : $TEXT2"
ui_print "  3) Deepsleep enhancer        : $TEXT3"
ui_print "  4) Zram size                 : $TEXT4"
ui_print "  5) Swap ram size             : $TEXT5"
ui_print "  6) GMS doze                  : $TEXT6"
ui_print "  7) Wifi bonding              : $TEXT7"
ui_print "  8) Dex2oat optimizer         : $TEXT8"
ui_print "  9) Built-in magisk busybox   : $TEXT9"
ui_print ""

# Create mod paths
    rm -rf $MODPATH 2>/dev/null
    mkdir -p $MODPATH

	SKIPUNZIP=1
    enforce_install_from_app
    if [ "$KSU" ]; then
        check_ksu_version
        check_zygisksu_version
        mountksu
    else
        check_magisk_version
    fi
    on_install
    sleep 1
	GpuCh
	sleep 1
	InstallGki
    ui_print "- Setting permissions"
    set_permissions

    # Remove placeholder
    rm -f $MODPATH/system/placeholder 2>/dev/null

    # Custom uninstaller
    [ -f $TMPDIR/uninstall.sh ] && cp -af $TMPDIR/uninstall.sh $MODPATH/uninstall.sh

    # Auto Mount
    if imageless_magisk; then
        $SKIPMOUNT && touch $MODPATH/skip_mount
    else
        $SKIPMOUNT || touch $MODPATH/auto_mount
    fi
    sleep 1
    # prop files
    $PROPFILE && cp -af $TMPDIR/system.prop $MODPATH/system.prop
    sleep 1
    # Module info
    cp -af $TMPDIR/module.prop $MODPATH/module.prop
    if $BOOTMODE; then
        # Update info for Magisk Manager
        if imageless_magisk; then
            mktouch $NVBASE/modules/$MODID/update
            cp -af $TMPDIR/module.prop $NVBASE/modules/$MODID/module.prop
        else
            mktouch /sbin/.magisk/img/$MODID/update
            cp -af $TMPDIR/module.prop /sbin/.magisk/img/$MODID/module.prop
        fi
    fi

    # service mode scripts
    $LATESTARTSERVICE && cp -af $TMPDIR/service.sh $MODPATH/service.sh

    # Handle replace folders
    for TARGET in $REPLACE; do
        mktouch $MODPATH$TARGET/.replace
    done

    ##########################################################################################
    # Finalizing
    ##########################################################################################

    cd /
    imageless_magisk || unmount_magisk_img
    $BOOTMODE || recovery_cleanup
    rm -rf $TMPDIR $MOUNTPATH
    
sleep 2
ui_print "  10) GPU Rendering		    : $TEXT10"
ui_print "  11) GPU Composition          : $TEXT11"
ui_print "  11) Install Or Remove Module : $TEXT12"
ui_print ""
ui_print "     - Apply options"
exit 0

enforce_install_from_app() {
  if $BOOTMODE; then
    ui_print "- Installing from Magisk / KernelSU app"
  else
    ui_print "*********************************************************"
    ui_print "! Install from recovery is NOT supported"
    ui_print "! Recovery sucks"
    ui_print "! Please install from Magisk / KernelSU app"
    abort "*********************************************************"
  fi
}

check_magisk_version() {
  ui_print "- Magisk version: $MAGISK_VER_CODE"
  if [ "$MAGISK_VER_CODE" -lt 20400 ]; then
    ui_print "*********************************************************"
    ui_print "! Please install Magisk v20.4+ (20400+)"
    abort    "*********************************************************"
  fi
}

check_ksu_version() {
  ui_print "- KernelSU version: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
  if ! [ "$KSU_KERNEL_VER_CODE" ] || [ "$KSU_KERNEL_VER_CODE" -lt 10940 ]; then
    ui_print "*********************************************************"
    ui_print "! KernelSU version is too old!"
    ui_print "! Please update KernelSU to latest version"
    abort    "*********************************************************"
  elif [ "$KSU_KERNEL_VER_CODE" -ge 20000 ]; then
    ui_print "*********************************************************"
    ui_print "! KernelSU version abnormal!"
    ui_print "! Please integrate KernelSU into your kernel"
    ui_print "  as submodule instead of copying the source code"
    abort    "*********************************************************"
  fi
  if ! [ "$KSU_VER_CODE" ] || [ "$KSU_VER_CODE" -lt 10942 ]; then
    ui_print "*********************************************************"
    ui_print "! ksud version is too old!"
    ui_print "! Please update KernelSU Manager to latest version"
    abort    "*********************************************************"
  fi
}

check_zygisksu_version() {
  ZYGISKSU_VERSION=$(cat /data/adb/modules/zygisksu/module.prop | grep versionCode | sed 's/versionCode=//g')
  ui_print "- Zygisksu version: $ZYGISKSU_VERSION"
  if ! [ "$ZYGISKSU_VERSION" ] || [ "$ZYGISKSU_VERSION" -lt 45 ]; then
    ui_print "*********************************************************"
    ui_print "! Zygisksu version is too old!"
    ui_print "! Please update Zygisksu to latest version"
    abort    "*********************************************************"
  fi
}

# Install gms doze
if [[ $(getprop trtweak.install.gmsdoze) == "1" ]]; then
  gms_doze_installer
fi

# Move vendor
cp -R $MODPATH/vendor $MODPATH/system

on_install() {
  ui_print "     KS A B A R  L A G I  D I  E X T R A K  A N J I N K "
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'sepolicy.rule' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'addon/*' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'module.prop' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'post-fs-data.sh' -d $MODPATH >&2
  unzip -o "$ZIPFILE" 'service.sh' -d $MODPATH >&2

# Set permissions
ui_print "     - Setting permissions "
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
set_perm_recursive $MODPATH/script 0 0 0755 0755

# Install toast app
ui_print "     - Install toast app "
pm install $MODPATH/Toast.apk

# Clean up
find $MODPATH/* -maxdepth 0 \
              ! -name 'module.prop' \
              ! -name 'post-fs-data.sh' \
              ! -name 'service.sh' \
              ! -name 'sepolicy.rule' \
              ! -name 'system.prop' \
              ! -name 'uninstall.sh' \
              ! -name 'system' \
              ! -name 'script' \
                -exec rm -rf {} \;

# Check trtweak directory
if [ ! -e /storage/emulated/0/trtweak ]; then
  mkdir /storage/emulated/0/trtweak
fi

# Check applist file
if [ ! -e /storage/emulated/0/trtweak/applist_perf.txt ]; then
  cp -f $MODPATH/script/applist_perf.txt /storage/emulated/0/trtweak
fi
    
