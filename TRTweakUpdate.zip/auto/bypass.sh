check_battery() {
# Mengambil level baterai
battery_level=$(dumpsys battery | grep "level" | awk '{print $2}')

# Memeriksa apakah baterai mencapai 90%
if [ "$battery_level" -ge 97 ]; then
    # Menjalankan script jika baterai mencapai 90%
    echo "Level baterai mencapai 97% atau lebih"
    chmod 0777 /sys/kernel/fast_charge/force_fast_charge
    echo 1 > /sys/kernel/fast_charge/force_fast_charge
    chmod 0444 /sys/kernel/fast_charge/force_fast_charge
    
    chmod 0777 /sys/class/power_supply/battery/constant_charge_current_max
    echo 1300000 > /sys/class/power_supply/battery/constant_charge_current_max
    chmod 0444 /sys/class/power_supply/battery/constant_charge_current_max
    
    chmod 0755 /sys/class/power_supply/battery/input_current_limited
    echo 0 > /sys/class/power_supply/battery/input_current_limited
    chmod 0644 /sys/class/power_supply/battery/input_current_limited
    
    chmod 0755 /sys/class/power_supply/battery/step_charging_enabled
    echo 1 > /sys/class/power_supply/battery/step_charging_enabled
    chmod 0644 /sys/class/power_supply/battery/step_charging_enabled
    
    chmod 0755 /sys/class/power_supply/battery/sw_jeita_enabled
    echo 1 > /sys/class/power_supply/battery/sw_jeita_enabled
    chmod 0644 /sys/class/power_supply/battery/sw_jeita_enabled
    
    chmod 0755 /sys/class/power_supply/battery/battery_charging_enabled
    echo 1 > /sys/class/power_supply/battery/battery_charging_enabled
    chmod 0644 /sys/class/power_supply/battery/battery_charging_enabled
    
    chmod 0755 /sys/class/power_supply/battery/subsystem/usb/pd_active
    echo 0 > /sys/class/power_supply/battery/subsystem/usb/pd_active
    chmod 0644 /sys/class/power_supply/battery/subsystem/usb/pd_active
    
    chmod 0755 /sys/class/power_supply/battery/charger_temp
    echo 470 > /sys/class/power_supply/battery/charger_temp
    chmod 0644 /sys/class/power_supply/battery/charger_temp
    
    chmod 0755 /sys/class/qcom-battery/restrict_chg
    echo 0 > /sys/class/qcom-battery/restrict_chg
    chmod 0644 /sys/class/qcom-battery/restrict_chg
looopping
else
    echo "Level baterai kurang dari 93%"
    sleep 10
    chmod 0777 /sys/kernel/fast_charge/force_fast_charge
    echo 1 > /sys/kernel/fast_charge/force_fast_charge
    chmod 0444 /sys/kernel/fast_charge/force_fast_charge
    
    chmod 0777 /sys/class/power_supply/battery/constant_charge_current_max
    echo 7000000 > /sys/class/power_supply/battery/constant_charge_current_max
    chmod 0444 /sys/class/power_supply/battery/constant_charge_current_max
    
    chmod 0755 /sys/class/power_supply/battery/input_current_limited
    echo 0 > /sys/class/power_supply/battery/input_current_limited
    chmod 0644 /sys/class/power_supply/battery/input_current_limited
    
    chmod 0755 /sys/class/power_supply/battery/step_charging_enabled
    echo 1 > /sys/class/power_supply/battery/step_charging_enabled
    chmod 0644 /sys/class/power_supply/battery/step_charging_enabled
    
    chmod 0755 /sys/class/power_supply/battery/sw_jeita_enabled
    echo 1 > /sys/class/power_supply/battery/sw_jeita_enabled
    chmod 0644 /sys/class/power_supply/battery/sw_jeita_enabled
    
    chmod 0755 /sys/class/power_supply/battery/battery_charging_enabled
    echo 1 > /sys/class/power_supply/battery/battery_charging_enabled
    chmod 0644 /sys/class/power_supply/battery/battery_charging_enabled
    
    chmod 0755 /sys/class/power_supply/battery/subsystem/usb/pd_active
    echo 0 > /sys/class/power_supply/battery/subsystem/usb/pd_active
    chmod 0644 /sys/class/power_supply/battery/subsystem/usb/pd_active
    
    chmod 0755 /sys/class/power_supply/battery/charger_temp
    echo 470 > /sys/class/power_supply/battery/charger_temp
    chmod 0644 /sys/class/power_supply/battery/charger_temp
    
    chmod 0755 /sys/class/qcom-battery/restrict_chg
    echo 0 > /sys/class/qcom-battery/restrict_chg
    chmod 0644 /sys/class/qcom-battery/restrict_chg
    looopping
fi
}

looopping() {
# Perulangan untuk menjalankan pengecekan setiap 10 detik
while true; do
    check_battery  # Memanggil fungsi pengecekan baterai
    sleep 10       # Menunggu selama 10 detik sebelum pengecekan selanjutnya
done
}

looopping