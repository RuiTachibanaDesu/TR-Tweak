#!/system/bin/sh

# Waiting for boot completed
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do sleep 3; done

# Detect temproot
if [ -e /data/local/tmp/magisk ]; then
  sleep 20
else
  sleep 3
fi

# Path
MODDIR=${0%/*}

# Variables
ZRAMSIZE=0
SWAPSIZE=0

# Device online functions
wait_until_login()
{
    # whether in lock screen, tested on Android 7.1 & 10.0
    # in case of other magisk module remounting /data as RW
    while [ "$(dumpsys window policy | grep mInputRestricted=true)" != "" ]; do
        sleep 2
    done
    # we doesn't have the permission to rw "/sdcard" before the user unlocks the screen
    while [ ! -d "/sdcard/Android" ]; do
        sleep 2
    done
}

# Zram functions
disable_zram()
{
    swapoff /dev/block/zram0
    echo "0" > /sys/class/zram-control/hot_remove
}

change_zram()
{
    sleep 5
    swapoff /dev/block/zram0
    echo "1" > /sys/block/zram0/reset
    echo "$ZRAMSIZE" > /sys/block/zram0/disksize
    mkswap /dev/block/zram0
    swapon /dev/block/zram0
}

# Swap functions
change_swap()
{
    if [ ! -e $MODDIR/swapram_installed ]; then
      if test -f "/data/swap"; then
        rm -f /data/swap
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        swapon /data/swap
      else
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        swapon /data/swap
      fi
      touch $MODDIR/swapram_installed
    else
      if test -f "/data/swap"; then
        swapon /data/swap
      else
        dd if=/dev/zero of=/data/swap bs=1024 count=$SWAPSIZE
        mkswap /data/swap
        swapon /data/swap
      fi
    fi
}

# GMS doze functions
gms_doze_enable()
{
GMS="com.google.android.gms"
GC1="auth.managed.admin.DeviceAdminReceiver"
GC2="mdm.receivers.MdmDeviceAdminReceiver"
NLL="/dev/null"
for U in $(ls /data/user); do
  for C in $GC1 $GC2 $GC3; do
    pm disable --user $U "$GMS/$GMS.$C" &> $NLL
  done
done
dumpsys deviceidle whitelist -com.google.android.gms &> $NLL
}

# Dex2oat opt function
dex2oat_opt_enable()
{
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ ⛔ Dex2oat Optimizer is running... ] /g' "$MODDIR/module.prop"
su -lp 2000 -c "cmd notification post -S bigtext -t 'TR-Tweak' tag '⛔ Dex2oat Optimizer is running...'" >/dev/null 2>&1
dexoat_opt
}

# Deepsleep functions
doze_default()
{
    dumpsys deviceidle enable
}

doze_light()
{
    sleep 3
    dumpsys deviceidle enable && settings put global device_idle_constants light_after_inactive_to=120000,light_pre_idle_to=120000,light_idle_to=600000,light_max_idle_to=3600000,locating_to=120000,location_accuracy=50,inactive_to=600000,sensing_to=120000,motion_inactive_to=300000,idle_after_inactive_to=300000
}

doze_moderate()
{
    sleep 3
    dumpsys deviceidle enable && settings put global device_idle_constants light_after_inactive_to=60000,light_pre_idle_to=60000,light_idle_to=900000,light_max_idle_to=10800000,locating_to=60000,location_accuracy=100,inactive_to=60000,sensing_to=60000,motion_inactive_to=60000,idle_after_inactive_to=60000,idle_to=7200000,max_idle_to=28800000,quick_doze_delay_to=30000,min_time_to_alarm=1800000
}

doze_high()
{
    sleep 3
    dumpsys deviceidle enable && settings put global device_idle_constants light_after_inactive_to=5000,light_pre_idle_to=30000,light_idle_to=1800000,light_max_idle_to=21600000,locating_to=10000,location_accuracy=500,inactive_to=30000,sensing_to=30000,motion_inactive_to=30000,idle_after_inactive_to=30000,idle_to=14400000,max_idle_to=43200000,quick_doze_delay_to=10000,min_time_to_alarm=600000
}

doze_extreme()
{
    sleep 3
    dumpsys deviceidle enable && settings put global device_idle_constants light_after_inactive_to=0,light_pre_idle_to=5000,light_idle_to=3600000,light_max_idle_to=43200000,locating_to=5000,location_accuracy=1000,inactive_to=0,sensing_to=0,motion_inactive_to=0,idle_after_inactive_to=0,idle_to=21600000,max_idle_to=172800000,quick_doze_delay_to=5000,min_time_to_alarm=300000
}

# Device online
wait_until_login

# Enable all tweak
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ 🚴 Apply tweaks please wait... ] /g' "$MODDIR/module.prop"
su -lp 2000 -c "cmd notification post -S bigtext -t 'TR-Tweak' tag '🚴 Apply tweaks please wait...'" >/dev/null 2>&1

# Sync to data in the rare case a device crashes
sync

# Change zram
#change_zram

# Swap ram
#change_swap

# Task scheduler
echo "20" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "4000000" > /proc/sys/kernel/sched_latency_ns
echo "15000000" > /proc/sys/kernel/sched_wakeup_granularity_ns
echo "10000000" > /proc/sys/kernel/sched_min_granularity_ns
echo "5000000" > /proc/sys/kernel/sched_migration_cost_ns
echo "32" > /proc/sys/kernel/sched_nr_migrate
echo "15" > /proc/sys/kernel/sched_min_task_util_for_boost
echo "1000" > /proc/sys/kernel/sched_min_task_util_for_colocation
echo "100" > /proc/sys/kernel/sched_rr_timeslice_ns
echo "1000000" > /proc/sys/kernel/sched_rt_period_us
echo "950000" > /proc/sys/kernel/sched_rt_runtime_us
echo "0" > /proc/sys/kernel/sched_autogroup_enabled
echo "0" > /proc/sys/kernel/sched_tunable_scaling
echo "0" > /proc/sys/kernel/sched_child_runs_first
echo "0" > /proc/sys/kernel/sched_schedstats
echo "0" > /proc/sys/kernel/timer_migration

# Lpm
echo "0" > /sys/module/lpm_levels/parameters/lpm_prediction
echo "0" > /sys/module/lpm_levels/parameters/sleep_disabled

#Ram Tweak
write "$VM/vfs_cache_pressure" 50
write "$VM/stat_interval" 15
write "$VM/compaction_proactiveness" 0
write "$VM/page-cluster" 0
write "$VM/swappiness" 100
write "$VM/dirty_ratio" 30

# Disable printk
echo "0 0 0 0" > /proc/sys/kernel/printk
echo "off" > /proc/sys/kernel/printk_devkmsg

# Disable cpu input boost
echo "0" > /sys/module/cpu_boost/parameters/sched_boost_on_input
echo "0" > /sys/module/cpu_boost/parameters/input_boost_ms
echo "0:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "1:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "2:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "3:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "4:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "5:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "6:0" > /sys/module/cpu_boost/parameters/input_boost_freq
echo "7:0" > /sys/module/cpu_boost/parameters/input_boost_freq

# Schedtune boost
echo "1" > /dev/stune/schedtune.sched_boost_enabled
echo "0" > /dev/stune/schedtune.boost
echo "0" > /dev/stune/schedtune.sched_boost_no_override
echo "0" > /dev/stune/schedtune.prefer_idle
echo "1" > /dev/stune/background/schedtune.sched_boost_enabled
echo "-15" > /dev/stune/background/schedtune.boost
echo "0" > /dev/stune/background/schedtune.sched_boost_no_override
echo "0" > /dev/stune/background/schedtune.prefer_idle
echo "1" > /dev/stune/foreground/schedtune.sched_boost_enabled
echo "0" > /dev/stune/foreground/schedtune.boost
echo "1" > /dev/stune/foreground/schedtune.sched_boost_no_override
echo "0" > /dev/stune/foreground/schedtune.prefer_idle
echo "1" > /dev/stune/rt/schedtune.sched_boost_enabled
echo "0" > /dev/stune/rt/schedtune.boost
echo "0" > /dev/stune/rt/schedtune.sched_boost_no_override
echo "0" > /dev/stune/rt/schedtune.prefer_idle
echo "1" > /dev/stune/top-app/schedtune.sched_boost_enabled
echo "0" > /dev/stune/top-app/schedtune.boost
echo "1" > /dev/stune/top-app/schedtune.sched_boost_no_override
echo "1" > /dev/stune/top-app/schedtune.prefer_idle

# Disable Adreno snapshot crashdumper
echo "0" > /sys/class/kgsl/kgsl-3d0/snapshot/snapshot_crashdumper

#I/O
echo "noop" > /sys/block/mmcblk0/queue/scheduler
echo "noop" > /sys/block/sda/queue/scheduler
echo "noop" > /sys/block/sdb/queue/scheduler
echo "noop" > /sys/block/sdc/queue/scheduler

# Disable multi core power saving
mcps="/sys/devices/system/cpu/sched_mc_power_savings"
if [[ -e "$mcps" ]]; then
  write "0" $mcps
fi

# Limit thermal ignore
glti="/proc/gpufreq/gpufreq_limited_thermal_ignore"
if [[ -e "$glti" ]]; then
  write "1" $glti
fi

# Gaming Touch For Kangaroox
if [[ -e "/sys/devices/virtual/touch/touch_dev/bump_sample_rate" ]]; then
  write "1" /sys/devices/virtual/touch/touch_dev/bump_sample_rate
fi

# Enable Fast Charging Rate
if [[ -e "/sys/kernel/fast_charge/force_fast_charge" ]]; then
  write "1" /sys/kernel/fast_charge/force_fast_charge
fi

#Touchscreen
echo '7035' > /sys/class/touch/switch/set_touchscreen;
echo '8002' > /sys/class/touch/switch/set_touchscreen;
echo '11000' > /sys/class/touch/switch/set_touchscreen;
echo '13060' > /sys/class/touch/switch/set_touchscreen;
echo '14005' > /sys/class/touch/switch/set_touchscreen;

#write /proc/sys/kernel/sched_lib_name "com.miHoYo., com.activision., UnityMain, libunity.so, libil2cpp.so"
write /proc/sys/kernel/sched_lib_name "com.miHoYo., com.activision., com.epicgames, com.dts., UnityMain, libunity.so, libil2cpp.so, libmain.so, libcri_vip_unity.so, libopus.so, libxlua.so, libUE4.so, libAsphalt9.so, libnative-lib.so, libRiotGamesApi.so, libResources.so, libagame.so, libapp.so, libflutter.so, libMSDKCore.so, libFIFAMobileNeon.so, libUnreal.so, libEOSSDK.so, libcocos2dcpp.so"
write /proc/sys/kernel/sched_lib_mask_force "240"

#write /proc/sys/kernel/sched_lib_mask_force 255
echo "240" > /proc/sys/kernel/sched_lib_mask_force
sleep 1

#Kernel Mu Lagi Biar Touch Ngatcheng
echo "55" > /proc/sys/kernel/perf_cpu_time_max_percent
echo "24000" > /proc/sys/kernel/perf_event_max_sample_rate
echo "570" > /proc/sys/kernel/perf_event_mlock_kb
echo "95" > /proc/sys/kernel/sched_downmigrate
echo "160" > /proc/sys/kernel/sched_group_upmigrate

#Kernelmu Biar Kaga Panik Kek Elu 
echo 0 > "/proc/sys/kernel/panic"
echo 0 > "/proc/sys/kernel/panic_on_oops"
echo 0 > "/proc/sys/kernel/panic_on_rcu_stall"
echo 0 > "/proc/sys/kernel/panic_on_warn"
echo 0 > "/proc/sys/kernel/softlockup_panic"
echo 0 > "/sys/module/kernel/parameters/panic"
echo 0 > "/sys/module/kernel/parameters/panic_on_warn"
echo 0 > "/sys/module/kernel/parameters/panic_on_oops"

#CAF Tweak
if [[ -d "/sys/module/cpu_boost" ]]
then
	write "/sys/module/cpu_boost/parameters/input_boost_freq" 0:1800000
	write "/sys/module/cpu_boost/parameters/input_boost_ms" 230
fi

#PRM
echo 0 > /sys/module/subsystem_restart/parameters/enable_ramdumps
echo 0 > /sys/module/subsystem_restart/parameters/enable_mini_ramdumps
echo Y > /sys/module/lpm_levels/parameters/sleep_disabled
echo 3 > /proc/sys/vm/drop_caches

#Disable CPU Hotplug
for i in /sys/devices/system/cpu/cpu[0,4,7]/core_ctl ; do
    chmod 666 $i/enable
	echo 0 > $i/enable
	chmod 444 $i/enable
done

#Fsync
chmod 666 /sys/module/sync/parameters/fsync_enable
chown root /sys/module/sync/parameters/fsync_enable
echo 'N' > /sys/module/sync/parameters/fsync_enabled

#R/H
echo "0" > /sys/block/mmcblk0/queue/add_random
echo "0" > /sys/block/mmcblk0/queue/iostats
echo "0" > /sys/block/mmcblk0/queue/nomerges
echo "0" > /sys/block/mmcblk0/queue/rotational
echo "1" > /sys/block/mmcblk0/queue/rq_affinity
echo "320" > /sys/block/mmcblk0/queue/nr_requests
echo "512" > /sys/block/mmcblk0/queue/read_ahead_kb

echo "0" > /sys/block/sda/queue/add_random
echo "0" > /sys/block/sda/queue/iostats
echo "0" > /sys/block/sda/queue/nomerges
echo "0" > /sys/block/sda/queue/rotational
echo "1" > /sys/block/sda/queue/rq_affinity
echo "320" > /sys/block/sda/queue/nr_requests
echo "512" > /sys/block/sda/queue/read_ahead_kb

echo "0" > /sys/block/sdb/queue/add_random
echo "0" > /sys/block/sdb/queue/iostats
echo "0" > /sys/block/sdb/queue/nomerges
echo "0" > /sys/block/sdb/queue/rotational
echo "1" > /sys/block/sdb/queue/rq_affinity
echo "320" > /sys/block/sdb/queue/nr_requests
echo "512" > /sys/block/sdb/queue/read_ahead_kb

echo "0" > /sys/block/sdc/queue/add_random
echo "0" > /sys/block/sdc/queue/iostats
echo "0" > /sys/block/sdc/queue/nomerges
echo "0" > /sys/block/sdc/queue/rotational
echo "1" > /sys/block/sdc/queue/rq_affinity
echo "320" > /sys/block/sdc/queue/nr_requests
echo "512" > /sys/block/sdc/queue/read_ahead_kb 

#Parameter
echo 0 > /sys/module/rmnet_data/parameters/rmnet_data_log_level
echo 0 > /sys/kernel/debug/rpm_log
echo 0 > /d/tracing/tracing_on

for i in $(find /sys/ -name debug_mask); do
echo "0" > $i;
done
for i in $(find /sys/ -name debug_level); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ce); do
echo "0" > $i;
done
for i in $(find /sys/ -name edac_mc_log_ue); do
echo "0" > $i;
done
for i in $(find /sys/ -name enable_event_log); do
echo "0" > $i;
done
for i in $(find /sys/ -name log_ecn_error); do
echo "0" > $i;
done
for i in $(find /sys/ -name snapshot_crashdumper); do
echo "0" > $i;
done

for i in /sys/devices/virtual/block/*/queue/iosched; do
  echo "0" > $i/low_latency;
done;

if [ -e "/sys/module/xhci_hcd/parameters/wl_divide" ]; then
echo "N" > /sys/module/xhci_hcd/parameters/wl_divide
fi

# Script for delete apps
function delete()
{
  if pm list packages -e 2>/dev/null | grep $1; then
  su -c pm uninstall --user 0 $1
  fi
}

# Unity big little trick
for cpuinfo in /sys/devices/system/cpu/cpu[0-7]; do
    chmod 000 "$cpuinfo/cpufreq/cpuinfo_max_freq"
    chmod 000 "$cpuinfo/cpu_capacity"
    chmod 000 "$cpuinfo/topology/physical_package_id"
done

# Gpu tuner force on
su -c cmd settings put global GPUTUNER_SWITCH "true"

# Force game driver
package_filter="cut -f 2 -d ":""
line_row_filter="tail -1"

list="com.miHoYo.|com.mobile.legends|com.primatelabs.geekbench6|com.percent.royaldice|com.riotgames|DriftRacing|com.supercell.brawlstars|apexlegendsmobile|com.roblox.client|com.activision.callofduty.shooter|com.pubg.imobile|ent.criticalops|com.axlebolt.standoff|io.anuke.mindustry|com.wb.goog.mkx|com.supercell.clashroyale|com.carxtech.sr|com.netease.wotb|com.tencent.tmgp.sgame|com.tencent.lolm|com.garena.game.kgtw|com.futuremark.dmandroid.application|com.carxtech.carxdr2|com.tencent.ig|com.tap4fun.ape.gplay|com.gof.global|net.wargaming.wot.blitz|com.riotgames.league.wildrift|com.blizzard.diablo.immortal|com.foursakenmedia.wartortoise2|com.mechanist.poi|com.olzhas.carparking.multyplayer|au.com.metrotrains.beansholiday|com.playside.dwtd6|com.playside.dwtd3|com.matteljv.uno|com.popreach.dumbways|air.au.com.metro.DumbWaysToDie2"

games="$(pm list packages | $package_filter | egrep "$list" | tr '\n' ' ' | tr ' ' ',' | sed 's/,*$//g')"

# Old Game driver
if [[ "$Android" == "10" ]]; then
    # Restore game driver apps
    settings put global game_driver_opt_in_apps ""
    
    # Set Gaming driver
    settings put global game_driver_opt_in_apps "$games"
fi

# New Game driver
if [[ "$Android" -gt "10" ]]; then
    # Restore game driver apps
    settings put global updatable_driver_all_apps "0"
    settings put global updatable_driver_production_opt_in_apps ""

    # Set Gaming driver
    settings put global updatable_driver_production_opt_in_apps "$games"
fi

#???
delete com.miui.analytics # Deleting background logs
delete com.miui.msa.global # Miui System Ads = MSA
delete com.facebook.services # Uselles facebook services
delete com.facebook.system # Uselles facebook services
delete com.facebook.appmanager # Uselles facebook services
delete com.android.traceur # Deleting background logs

# Better rendering speed
change_task_cgroup "surfaceflinger" "" "cpuset"
change_task_cgroup "surfaceflinger" "" "stune"
change_task_cgroup "android.hardware.graphics.composer" "" "cpuset"
change_task_cgroup "android.hardware.graphics.composer" "" "stune"

upgrade_miui() {
# Check if we're running MIUI
  [[ "$(getprop ro.miui.ui.version.name)" ]] && miui=true
  
  [[ "$miui" == "true" ]] && {
  # Cpu sets
  write "0-2,4-7" /dev/cpuset/foreground/cpus
  }

  nr_cores=$(cat /sys/devices/system/cpu/possible | awk -F "-" '{print $2}')
  nr_cores=$((nr_cores+1))

  [[ "$nr_cores" -eq "0" ]] && nr_cores=1

  [[ "$miui" == "true" ]] && [[ "$nr_cores" == "8" ]] && {
  resetprop persist.sys.miui.sf_cores "4-7"
  resetprop persist.sys.miui_animator_sched.bigcores "4-7"
  }

  [[ "$miui" == "true" ]] && [[ "$nr_cores" == "6" ]] && {
  resetprop persist.sys.miui.sf_cores "0-5"
  resetprop persist.sys.miui_animator_sched.bigcores "2-5"
  }

  [[ "$miui" == "true" ]] && [[ "$nr_cores" == "4" ]] && {
  resetprop persist.sys.miui.sf_cores "0-3"
  resetprop persist.sys.miui_animator_sched.bigcores "0-3"
  }
}

# Apply settings for miui
upgrade_miui

# Stop services
su -c stop tcpdump
su -c stop cnss_diag
su -c stop statsd
su -c stop traced
su -c stop miuibooster
su -c stop vendor.perfservice

#internal storage
 for int in /sys/block/sd*/queue
 do
   echo "cfq" > $int/scheduler
   echo "0" > $int/iosched/slice_idle
   echo "0" > $int/iosched/slice_idle_us
   echo "0" > $int/iosched/group_idle
   echo "0" > $int/iosched/group_idle_us
   echo "1" > $int/iosched/low_latency
   echo "120" > $int/iosched/target_latency
   echo "120000" > $int/iosched/target_latency_us
 done
#external storage
 for ext in /sys/block/mmc*/queue
 do
   echo "cfq" > $ext/scheduler
   echo "0" > $ext/iosched/slice_idle
   echo "0" > $ext/iosched/slice_idle_us
   echo "0" > $ext/iosched/group_idle
   echo "0" > $ext/iosched/group_idle_us
   echo "1" > $ext/iosched/low_latency
   echo "120" > $ext/iosched/target_latency
   echo "120000" > $ext/iosched/target_latency_us
 done

# Entropy
echo "64" > /proc/sys/kernel/random/read_wakeup_threshold
echo "256" > /proc/sys/kernel/random/write_wakeup_threshold

# Blkio
if [ -d /dev/blkio ]; then
  echo "1000" > /dev/blkio/blkio.weight
  echo "200" > /dev/blkio/background/blkio.weight
  echo "2000" > /dev/blkio/blkio.group_idle
  echo "0" > /dev/blkio/background/blkio.group_idle
fi

# Activity manager
if [ $(getprop ro.build.version.sdk) -gt 28 ]; then
  device_config set_sync_disabled_for_tests none
  device_config put activity_manager max_cached_processes 64
  device_config put activity_manager max_empty_time_millis 1800000
  device_config put activity_manager max_phantom_processes 32
  settings put global settings_enable_monitor_phantom_procs true
else
  settings put global activity_manager_constants max_cached_processes=64
fi

#Permission
chmod 755 /data/adb/modules/TR-Tweak/service.sh
chmod +x /data/local/tmp/bypass.sh
su -c 'sh /data/local/tmp/bypass.sh'

#Dexoat Optimizer
#dex2oat_opt_enable

#x1

# Enable GMS doze
#gms_doze_enable

# Doze mode
#dozemode


# Done
sleep 3
sed -Ei 's/^description=(\[.*][[:space:]]*)?/description=[ ✅ All tweaks is applied... ] /g' "$MODDIR/module.prop"
su -lp 2000 -c "cmd notification post -S bigtext -t 'TR-Tweak' tag '✅ All tweaks is applied...'" >/dev/null 2>&1

# Run Ai
sleep 3
nohup sh $MODDIR/script/trtweak_auto.sh &
